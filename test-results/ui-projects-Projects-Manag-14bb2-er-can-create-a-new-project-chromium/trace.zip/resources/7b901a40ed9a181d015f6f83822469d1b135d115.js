(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/Desktop_planer-budowy_src_0sr0ptd._.js","static/chunks/0f1p_recharts_es6_util_0zmw~gj._.js","static/chunks/0f1p_recharts_es6_state_0iisdbm._.js","static/chunks/0f1p_recharts_es6_component_01jduw4._.js","static/chunks/0f1p_recharts_es6_0.w_yhe._.js","static/chunks/0f1p_0q_5aqm._.js"],
    source: "dynamic"
});
