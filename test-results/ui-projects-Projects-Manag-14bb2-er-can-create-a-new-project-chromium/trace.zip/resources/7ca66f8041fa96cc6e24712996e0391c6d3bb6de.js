(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0f1p_12_mjfz._.js","static/chunks/Desktop_planer-budowy_src_0emnpk0._.js"],
    source: "dynamic"
});
