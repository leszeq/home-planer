(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0f1p_01_~fjn._.js","static/chunks/Desktop_planer-budowy_src_lib_i18n_01vjlw_._.js","static/chunks/Desktop_planer-budowy_src_app_globals_0vw0u-r.css"],
    source: "dynamic"
});
