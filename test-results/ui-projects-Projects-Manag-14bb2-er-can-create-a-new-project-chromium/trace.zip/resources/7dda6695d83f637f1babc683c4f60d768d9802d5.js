(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_11j_r3y._.js","static/chunks/0f1p_next_dist_compiled_next-devtools_index_03b4gqf.js","static/chunks/0f1p_next_dist_compiled_react-dom_0t77p_5._.js","static/chunks/0f1p_next_dist_compiled_react-server-dom-turbopack_05-.65x._.js","static/chunks/0f1p_next_dist_compiled_0d60bpj._.js","static/chunks/0f1p_next_dist_client_0fdel4-._.js","static/chunks/0f1p_next_dist_0eiz6t9._.js","static/chunks/0f1p_@swc_helpers_cjs_0v43.xx._.js"],
    source: "entry"
});
