(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/planer-budowy/src/lib/i18n/locales/pl.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "pl",
    ()=>pl
]);
const pl = {
    "common": {
        "dashboard": "Dashboard",
        "projects": "Projekty",
        "all": "Wszystkie",
        "expenses": "Wydatki",
        "checklists": "Checklisty",
        "documents": "Dokumenty",
        "settings": "Ustawienia",
        "logout": "Wyloguj się",
        "cancel": "Anuluj",
        "save": "Zapisz",
        "delete": "Usuń",
        "edit": "Edytuj",
        "add": "Dodaj",
        "create": "Utwórz",
        "creating": "Tworzenie...",
        "loading": "Ładowanie...",
        "error": "Błąd",
        "success": "Sukces",
        "export_pdf": "Eksportuj PDF",
        "saved": "Zapisano!",
        "owner": "Właściciel",
        "editor": "Edytor",
        "viewer": "Widz",
        "search": "Szukaj...",
        "none": "Brak",
        "preview": "Podgląd",
        "download": "Pobierz",
        "confirm_delete": "Czy na pewno chcesz to usunąć?",
        "cannot_be_undone": "Tej operacji nie można cofnąć.",
        "deleting": "Usuwanie...",
        "close": "Zamknij",
        "brand_name_1": "Planer",
        "brand_name_2": "Budowy",
        "selected": "Wybrano",
        "select_all": "Zaznacz wszystkie",
        "deselect_all": "Odznacz wszystkie",
        "delete_selected": "Usuń wybrane",
        "sort_date_desc": "Data: od najnowszych",
        "sort_date_asc": "Data: od najstarszych",
        "sort_amount_desc": "Kwota: od największych",
        "sort_amount_asc": "Kwota: od najmniejszych",
        "no_search_results": "Brak wyników wyszukiwania",
        "error_field_required": "To pole jest wymagane",
        "select": "Wybierz..."
    },
    "auth": {
        "login_tab": "Zaloguj się",
        "register_tab": "Zarejestruj się",
        "welcome_back": "Witamy z powrotem",
        "create_account": "Załóż darmowe konto",
        "magiclink_title": "Zaloguj się bez hasła",
        "login_desc": "Wprowadź swoje dane, aby uzyskać dostęp do panelu.",
        "register_desc": "Dołącz do setek inwestorów, którzy kontrolują swoje budowy.",
        "magiclink_desc": "Wpisz email, a otrzymasz bezpieczny link do jednorazowego logowania.",
        "email_placeholder": "Adres e-mail",
        "password_placeholder": "Hasło",
        "login_button": "Zaloguj się",
        "register_button": "Utwórz konto",
        "send_link_button": "Wyślij link",
        "back_to_login": "Wróć do logowania z hasłem",
        "forgot_password": "Zapomniałeś hasła? Zaloguj się jednorazowym linkiem.",
        "hero_title": "Platforma dla ambitnych",
        "hero_accent": "Inwestorów",
        "hero_desc": "Zrezygnuj z chaotycznych arkuszy kalkulacyjnych. Trzymaj koszty w ryzach, weryfikuj postępy z gotowymi checklistami i przechowuj wszystkie umowy i paragony w jednym miejscu.",
        "social_proof": "Dołącz do pionierów cyfrowej budowy.",
        "errors": {
            "invalid_credentials": "Nieprawidłowe dane logowania.",
            "user_exists": "Konto z tym adresem e-mail już istnieje. Spróbuj się zalogować.",
            "email_not_confirmed": "Adres e-mail nie został potwierdzony. Sprawdź swoją skrzynkę."
        }
    },
    "landing": {
        "nav": {
            "dashboard_link": "Przejdź do Panelu",
            "login_link": "Zaloguj się",
            "get_started": "Rozpocznij za darmo"
        },
        "hero": {
            "badge": "Stworzone z myślą o inwestorach prywatnych",
            "title": "Zbuduj swój dom",
            "accent": "bez stresu i chaosu",
            "description": "Miej pełną kontrolę nad budżetem, zarządzaj wykonawcami, śledź postępy za pomocą ponad 280 punktów kontrolnych i trzymaj wszystkie umowy w jednym, bezpiecznym miejscu.",
            "cta_primary": "Załóż darmowe konto",
            "cta_secondary": "Poznaj funkcje",
            "dashboard_back": "Wróc do Panelu"
        },
        "features": {
            "title": "Wszystko, czego potrzebujesz",
            "subtitle": "Planer Budowy zastępuje dziesiątki arkuszy Excela, gubiące się paragony i zapiski na kolanie jednym, spójnym systemem.",
            "budget_title": "Pełna kontrola budżetu",
            "budget_desc": "Śledź każdy wydany grosz. Przydzielaj wydatki do konkretnych etapów, monitoruj odchylenia od zakładanego budżetu bazowego i oglądaj czytelne wykresy (Recharts), by dokładnie wiedzieć, czy starczy Ci środków do końca.",
            "checklists_title": "Ponad 280+ punktów na Checklistach",
            "checklists_desc": "Gotowe, profesjonalne szablony inspekcji dla 7 etapów budowy. Od fundamentów, przez zbrojenia po elewację. Nie daj się oszukać na budowie.",
            "timeline_title": "Harmonogram Drag & Drop",
            "timeline_desc": "Planuj kolejne ekipy bez stresu. Przesuwaj kafelki etapów w dowolnej kolejności na interaktywnej liście, układając chronologię robót pod własne dyktando.",
            "files_title": "Teczka Inwestora i Wzory Umów",
            "files_desc": "Koniec z szukaniem paragonów w kieszeniach spodni. Wrzucaj zdjęcia faktur, skany zatwierdzonych projektów prosto do nielimitowanego prywatnego sejfu zintegrowanego z Twoim projektem. Dodatkowo oferujemy gotowe szablony umów (m.in. umowa z generalnym wykonawcą)."
        },
        "cta": {
            "title": "Zbuduj dom na solidnych fundamentach...",
            "subtitle": "planowania.",
            "description": "Zacznij korzystać z platformy za darmo. Żadnych kart kredytowych, brak ukrytych opłat.",
            "button": "Załóż konto i dodaj swój pierwszy projekt"
        },
        "footer": {
            "rights": "Wszelkie prawa zastrzeżone."
        }
    },
    "checklists": {
        "header_title": "Harmonogram prac",
        "header_desc": "Zarządzaj etapami budowy i listami kontrolnymi",
        "title": "Twoje Checklisty",
        "page_title": "Checklisty",
        "page_subtitle": "Narzędzia kontroli jakości dla każdego etapu budowy",
        "create": "Utwórz Checklistę",
        "create_new": "Nowa checklista",
        "create_custom": "Utwórz własną listę",
        "group_by_project": "Grupuj wg Projektu",
        "all_projects": "Wszystkie Projekty",
        "no_items": "Brak zadań w tej liście.",
        "no_items_details": "Brak zadań. Kliknij + aby dodać pierwsze.",
        "add_item": "Dodaj zadanie",
        "add_item_placeholder": "Nowe zadanie...",
        "delete_confirm": "Czy na pewno chcesz usunąć tę checklistę?",
        "delete_item_confirm": "Usunąć?",
        "template_info": "Ta lista została utworzona z szablonu.",
        "items_count": "{count} zadań",
        "checklist_name": "Nazwa checklisty",
        "save": "Utwórz checklistę",
        "templates_banner_title": "10 profesjonalnych szablonów checklisty",
        "templates_banner_desc": "Gotowe listy kontrolne: fundamenty (54 pkt), płyta (30 pkt), stan surowy (92 pkt), okna (13 pkt), instalacje (78 pkt), termoizolacja (13 pkt), elewacja (18 pkt).",
        "no_checklists_title": "Brak checklisty",
        "no_checklists_desc": "Nie masz jeszcze żadnych list kontrolnych dla wybranych projektów. Dodaj nową listę z gotowego szablonu lub stwórz własną od zera.",
        "unknown_project": "Nieznany projekt",
        "add_from_template": "Dodaj z szablonu",
        "add_from_template_short": "Z szablonu",
        "select_template": "Wybierz szablon checklisty",
        "assign_to_stage": "Przypisz do etapu",
        "no_stage": "Bez etapu",
        "adding_template": "Dodawanie...",
        "added_from_template": "Checklista \"{{name}}\" została dodana.",
        "select_project": "Projekt",
        "custom_name_placeholder": "Np. Ważne zadania...",
        "list_items": "Pozycje na liście (zadania)",
        "add_custom": "+ Checklista"
    },
    "documents": {
        "header_title": "Dokumenty i Wzory",
        "header_desc": "Przeglądaj wszystkie dokumenty projektowe i korzystaj z gotowych wzorów pism",
        "title": "Dokumenty i wzory umów",
        "page_title": "Dokumenty i wzory umów",
        "page_subtitle": "Gotowe szablony dokumentów i umów budowlanych. Skopiuj treść, uzupełnij swoje dane i podpisz z wykonawcą.",
        "tab_templates": "Wzory i szablony",
        "tab_my_documents": "Moja teczka",
        "filter_all_projects": "Wszystkie budowy",
        "add_document": "Dodaj dokument",
        "add_document_desc": "Wgraj skan papierowej umowy lub wyślij dokument do podpisu.",
        "no_documents": "Brak przesłanych dokumentów",
        "no_documents_msg": "Twoja teczka jest pusta. Dodaj pierwszy dokument, aby zacząć go śledzić.",
        "mode_scan": "Skan / Plik",
        "mode_esign": "E-Podpis",
        "doc_name": "Nazwa dokumentu",
        "doc_name_placeholder": "np. Umowa z elektrykiem",
        "select_project": "Przypisz do projektu (opcjonalnie)",
        "no_project": "Brak (Dokument ogólny)",
        "click_to_upload": "Kliknij lub przeciągnij plik",
        "file_types_desc": "PDF lub Zdjęcie (JPG, PNG)",
        "esign_setup": "Konfiguracja Podpisu",
        "signer_name": "Imię i nazwisko odbiorcy",
        "signer_name_placeholder": "np. Jan Kowalski",
        "signer_email": "Adres e-mail odbiorcy",
        "esign_provider_info": "Dokument zostanie wysłany bezpiecznie via {provider}.",
        "error_missing_signer": "Proszę podać dane odbiorcy podpisu.",
        "upload_scan": "Wgraj skan",
        "send_to_sign": "Wyślij do podpisu",
        "uploading": "Wgrywanie...",
        "status_signed": "Podpisano",
        "status_pending": "Oczekuje",
        "status_rejected": "Odrzucono",
        "type_scan": "Skan",
        "type_esign": "E-Podpis",
        "open_provider": "Otwórz w BoldSign",
        "template_content_label": "Treść wzoru",
        "copy_content": "Kopiuj treść",
        "copied": "Skopiowano",
        "delete_confirm_msg": "Czy na pewno chcesz usunąć dokument \"{name}\"? Plik zostanie trwale usunięty z serwera.",
        "status_syncing": "Synchronizacja...",
        "tooltip_preview": "Podgląd dokumentu",
        "preview_error": "Nie udało się załadować podglądu.",
        "preview_error_hint": "Plik może być niedostępny lub uszkodzony.",
        "preview_not_supported": "Podgląd dla tego formatu nie jest wspierany.",
        "esign_preview_title": "Podgląd E-Podpisu",
        "esign_preview_desc": "Podgląd dokumentów BoldSign wymaga autoryzacji u dostawcy. Kliknij poniżej, aby otworzyć dokument.",
        "open_in_boldsign": "Otwórz w BoldSign",
        "syncing_status": "Synchronizacja statusu...",
        "status_synced": "Status zaktualizowany!",
        "sending_request": "Wysyłanie dokumentu do podpisu...",
        "error_missing_fields": "Wypełnij wszystkie wymagane pola"
    },
    "settings": {
        "header_title": "Ustawienia konta",
        "header_desc": "Zarządzaj swoim profilem i ustawieniami bezpieczeństwa",
        "account_settings": "Ustawienia Konta",
        "account_subtitle": "Zarządzaj swoimi danymi, zdjęciem profilowym i bezpieczeństwem.",
        "profile_tab": "Mój Profil",
        "security_tab": "Bezpieczeństwo",
        "full_name": "Imię i Nazwisko",
        "email": "E-mail",
        "phone_number": "Numer telefonu",
        "email_readonly_info": "Email można zmienić tylko w ustawieniach głównych auth.",
        "save_changes": "Zapisz zmiany",
        "saving": "Zapisywanie...",
        "saved": "Zapisano!",
        "password_hint": "Uwaga: Hasło musi zawierać minimum 8 znaków, w tym cyfrę i znak specjalny.",
        "current_password": "Aktualne Hasło",
        "new_password": "Nowe Hasło",
        "confirm_new_password": "Potwierdź Nowe Hasło",
        "password_success": "Hasło zostało pomyślnie zaktualizowane!",
        "update_password": "Zaktualizuj hasło",
        "profile": {
            "photo_title": "Twoje zdjęcie",
            "photo_desc": "Zalecane 400x400px. JPG, PNG lub WebP.",
            "change_photo": "Zmień zdjęcie",
            "errors": {
                "select_image": "Proszę wybrać plik obrazu.",
                "upload_failed": "Błąd podczas wgrywania zdjęcia."
            }
        }
    },
    "dashboard": {
        "welcome": "Witaj z powrotem",
        "summary": "Podsumowanie",
        "total_budget": "Całkowity Budżet",
        "total_spent": "Wydano łącznie",
        "active_projects": "Aktywne Projekty",
        "completed_stages": "Ukończone Etapy",
        "spending_by_category": "Wydatki wg Kategorii",
        "materials": "Materiały",
        "labor": "Robocizna",
        "other": "Inne",
        "stats": {
            "projects": "Projekty",
            "total_budget": "Łączny budżet",
            "spent": "Wydano",
            "remaining": "Pozostało",
            "selected_projects": "wybrane projekty",
            "active_projects": "aktywnych projektów",
            "in_selected": "w wybranych projektach",
            "in_all": "we wszystkich projektach",
            "budget_usage": "{progress}% budżetu",
            "to_use": "do wykorzystania",
            "all": "Wszystkie",
            "currency": "zł"
        },
        "alerts": {
            "near_limit": "Uwaga: zużyto już {progress}% budżetu",
            "over_budget": "Przekroczono budżet o {amount} zł!",
            "over_budget_plural": "Przekroczono budżet wybranych projektów o {amount} zł!"
        },
        "filter": "Filtruj:",
        "no_projects_match": "Brak projektów spełniających kryteria.",
        "recent_projects": "Twoje projekty",
        "investment_shortcut": "Panel główny",
        "budget_label": "budżet"
    },
    "projects": {
        "header_title": "Projekty",
        "header_desc": "Zarządzaj swoimi inwestycjami budowlanymi",
        "title": "Twoje Projekty",
        "new_project": "Nowy Projekt",
        "summary_subtitle": "Podsumowanie projektu i ustawienia",
        "budget_status": "Status Budżetu",
        "safe": "{percent}% bezpiecznie",
        "over_budget_msg": "Przekroczono Budżet!",
        "near_limit_msg": "Blisko Limitu",
        "on_track_msg": "Zgodnie z Planem",
        "budget_exceeded": "Budżet przekroczony!",
        "budget_warning": "Wykorzystano 80% budżetu.",
        "stage_progress": "Postęp Etapów",
        "completed_stages": "Ukończone etapy",
        "largest_category": "Największa Kategoria",
        "highest_spending": "Kategoria z największymi wydatkami",
        "delete_shared_confirm": "Czy na pewno chcesz usunąć ten projekt ze swojego konta? Nie usunie to projektu u właściciela.",
        "delete_owner_confirm": "Czy na pewno chcesz TRWALE usunąć ten projekt? Ta operacja jest nieodwracalna.",
        "project_name": "Nazwa Projektu",
        "budget": "Budżet",
        "create": "Utwórz Projekt",
        "no_projects": "Nie masz jeszcze żadnych projektów.",
        "delete_confirm": "Czy na pewno chcesz usunąć ten projekt?",
        "timeline": "Harmonogram",
        "stages": "Etapy Budowy",
        "team": "Zespół i Udostępnianie",
        "files": "Pliki i Dokumenty",
        "add_stage": "Dodaj Etap",
        "status_todo": "Do zrobienia",
        "status_in_progress": "W trakcie",
        "status_done": "Gotowe",
        "stage_added": "Etap \"{{name}}\" został dodany.",
        "stage_deleted": "Etap został usunięty.",
        "stage_status_changed": "Status zmieniony na \"{{status}}\".",
        "edit_budget": "Edytuj budżet",
        "budget_updated": "Budżet zaktualizowany do {{amount}} zł.",
        "summary_title": "Podsumowanie projektu",
        "controls_title": "Zarządzanie",
        "extra": {
            "subtitle": "Zarządzaj swoimi i udostępnionymi projektami budowlanymi.",
            "empty_title": "Brak projektów",
            "empty_desc": "Utwórz pierwszy projekt lub poproś o zaproszenie.",
            "shared_badge": "Udostępniony",
            "budget_label": "Budżet",
            "created_label": "Utworzono"
        }
    },
    "team": {
        "title": "Zespół i Udostępnianie",
        "description": "Zarządzaj dostępem do tego projektu. Osoby w zespole mogą edytować etapy i wydatki (Edytor) lub tylko je przeglądać (Obserwator).",
        "manage_team": "Zarządzaj zespołem",
        "add_person": "Dodaj osobę",
        "invite": "Zaproś",
        "invite_title": "Zaproś kogoś do projektu",
        "invite_placeholder": "adres@email.com",
        "main_owner": "Główny Właściciel",
        "you": "Ty (Twórca projektu)",
        "send_invite": "Wyślij zaproszenie",
        "connected": "Połączono",
        "waiting": "Oczekiwanie",
        "remove_member_confirm": "Czy na pewno chcesz usunąć tę osobę z projektu?",
        "error_duplicate": "Ten użytkownik jest już w zespole.",
        "no_members": "Brak zaproszonych osób."
    },
    "expenses": {
        "title": "Wydatki",
        "add_expense": "Dodaj Wydatek",
        "amount": "Kwota",
        "category": "Kategoria",
        "date": "Data",
        "description": "Opis",
        "no_expenses": "Brak wydatków w tym projekcie.",
        "category_materials": "Materiały",
        "category_labor": "Robocizna",
        "category_other": "Inne",
        "category_custom": "Inne (własna)",
        "stage": "Etap",
        "actions": "Akcje",
        "summary": "Podsumowanie wydatków",
        "edit_expense": "Edytuj wydatek",
        "expense_added": "Dodano wydatek \"{{desc}}\" ({{amount}} zł).",
        "expense_deleted": "Wydatek usunięty.",
        "expenses_deleted": "Usunięto {{count}} wydatków.",
        "expense_updated": "Wydatek zaktualizowany.",
        "custom_category_label": "Własna nazwa kategorii",
        "document_label": "Powiązany dokument",
        "upload_new": "Wgraj nowy",
        "link_existing": "Połącz z istniejącym",
        "select_file": "Wybierz plik...",
        "file_uploaded_success": "Plik z dokumentem został wgrany i zapisany.",
        "by_category": "Wydatki według kategorii",
        "stages_chart_title": "Wydatki na etap",
        "stages_chart_desc": "Zestawienie zaksięgowanych kosztów według etapów.",
        "no_stage": "Bez etapu",
        "global": {
            "title": "Twoje Wydatki",
            "subtitle": "Pełna historia wszystkich kosztów we wszystkich Twoich inwestycjach.",
            "search_placeholder": "Szukaj w wydatkach...",
            "all_projects": "Wszystkie projekty",
            "found_count": "Znaleziono: {count} pozycji",
            "total_sum": "Suma: ",
            "no_results": "Nie znaleziono wydatków spełniających kryteria.",
            "no_description": "Brak opisu",
            "table": {
                "date": "Data",
                "project": "Projekt",
                "description": "Opis",
                "category": "Kategoria",
                "amount": "Kwota"
            }
        }
    },
    "files": {
        "title": "Pliki i Dokumenty",
        "subtitle": "Paragony, umowy, zdjęcia z budowy",
        "upload": "Wgraj plik",
        "uploading": "Wgrywanie...",
        "no_files": "Brak plików w tym projekcie.",
        "no_files_details": "Brak plików. Wgraj pierwszy dokument.",
        "delete_confirm": "Na pewno usunąć ten plik?",
        "drag_drop": "Przeciągnij i upuść pliki tutaj",
        "drag_drop_subtitle": "lub kliknij aby wybrać z dysku (PDF, JPG, PNG)",
        "select_files": "Wybierz pliki",
        "download": "Pobierz",
        "delete": "Usuń",
        "size_limit": "Maksymalny rozmiar pliku: 10MB",
        "error_upload": "Błąd podczas przesyłania pliku: {name}",
        "error_download": "Nie udało się wygenerować linku do pobrania.",
        "assign_stage": "Przypisz do etapu",
        "type_pdf": "PDF",
        "type_image": "Zdjęcie",
        "type_document": "Dokument"
    },
    "stages": {
        "title": "Etapy Budowy",
        "add_stage": "Dodaj Nowy Etap",
        "no_stages": "Brak etapów. Dodaj pierwszy etap, aby zacząć.",
        "status": "Status",
        "order": "Kolejność",
        "delete_stage_confirm": "Czy na pewno chcesz usunąć ten etap wraz ze wszystkimi wydatkami?",
        "suggested_title": "Wpisz własną nazwę lub wybierz poniżej...",
        "suggested_list": [
            "Działka i formalności",
            "Stan zero (Fundamenty, Płyta)",
            "Stan surowy otwarty",
            "Stan surowy zamknięty (Okna, Dach)",
            "Instalacje wewnętrzne",
            "Tynki i wylewki",
            "Termoizolacja poddasza",
            "Ocieplenie i elewacja",
            "Prace wykończeniowe",
            "Urządzanie i meble",
            "Odbiór i przeprowadzka"
        ],
        "start_date": "Data Rozpoczęcia",
        "end_date": "Data Zakończenia",
        "save_dates": "Zapisz Daty",
        "timeline_title": "Harmonogram Projektu",
        "timeline_duration": "Czas trwania: {days} dni (od {start} do {end})",
        "no_timeline_data": "Brak danych do harmonogramu",
        "no_timeline_details": "Dodaj datę rozpoczęcia i zakończenia do etapów budowy.",
        "predefined": {
            "Działka": "Działka",
            "Formalności": "Formalności",
            "Fundamenty": "Fundamenty",
            "Stan surowy": "Stan surowy",
            "Instalacje": "Instalacje",
            "Wykończenie": "Wykończenie"
        }
    },
    "activity": {
        "title": "Historia zmian",
        "subtitle": "Najnowsze wydarzenia w projekcie",
        "no_logs": "Brak zarejestrowanej historii",
        "create_expense": "Dodano wydatek: {name} ({amount} zł)",
        "delete_expense": "Usunięto wydatek: {name}",
        "delete_expense_bulk": "Usunięto zbiorczo {count} wydatków",
        "create_stage": "Utworzono etap: {name}",
        "delete_stage": "Usunięto etap: {name}",
        "update_stage_status": "Zmieniono status etapu {name} na {status}",
        "upload_file": "Wgrano plik: {name}",
        "delete_file": "Usunięto plik: {name}",
        "delete_file_bulk": "Usunięto zbiorczo {count} plików",
        "invite_member": "Zaproszono użytkownika: {email}",
        "remove_member": "Usunięto użytkownika: {email}",
        "update_stage_dates": "Zmieniono daty etapu: {name}",
        "update_expense": "Zaktualizowano wydatek: {name}",
        "update_file_stage": "Zmieniono przypisanie pliku: {name}",
        "update_member_role": "Zmieniono rolę: {email} ({role})",
        "update_project_budget": "Zmieniono budżet na {budget} zł"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/lib/i18n/locales/en.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "en",
    ()=>en
]);
const en = {
    "common": {
        "dashboard": "Dashboard",
        "projects": "Projects",
        "all": "All",
        "expenses": "Expenses",
        "checklists": "Checklists",
        "documents": "Documents",
        "settings": "Settings",
        "logout": "Sign Out",
        "cancel": "Cancel",
        "save": "Save",
        "delete": "Delete",
        "edit": "Edit",
        "add": "Add",
        "create": "Create",
        "creating": "Creating...",
        "loading": "Loading...",
        "error": "Error",
        "success": "Success",
        "export_pdf": "Export PDF",
        "saved": "Saved!",
        "owner": "Owner",
        "editor": "Editor",
        "viewer": "Viewer",
        "search": "Search...",
        "none": "None",
        "preview": "Preview",
        "download": "Download",
        "confirm_delete": "Are you sure you want to delete this?",
        "cannot_be_undone": "This operation cannot be undone.",
        "deleting": "Deleting...",
        "close": "Close",
        "brand_name_1": "Construction",
        "brand_name_2": "Planner",
        "selected": "Selected",
        "select_all": "Select All",
        "deselect_all": "Deselect All",
        "delete_selected": "Delete selected",
        "sort_date_desc": "Date: newest first",
        "sort_date_asc": "Date: oldest first",
        "sort_amount_desc": "Amount: higher first",
        "sort_amount_asc": "Amount: lower first",
        "no_search_results": "No results found",
        "error_field_required": "This field is required",
        "select": "Select..."
    },
    "auth": {
        "login_tab": "Log In",
        "register_tab": "Sign Up",
        "welcome_back": "Welcome back",
        "create_account": "Create free account",
        "magiclink_title": "Log in without password",
        "login_desc": "Enter your details to access the dashboard.",
        "register_desc": "Join hundreds of investors who control their construction projects.",
        "magiclink_desc": "Enter your email, and you'll receive a secure link for one-time login.",
        "email_placeholder": "Email address",
        "password_placeholder": "Password",
        "login_button": "Log In",
        "register_button": "Create Account",
        "send_link_button": "Send Link",
        "back_to_login": "Back to login with password",
        "forgot_password": "Forgot password? Log in with a one-time link.",
        "hero_title": "Platform for ambitious",
        "hero_accent": "Investors",
        "hero_desc": "Ditch chaotic spreadsheets. Keep costs in check, verify progress with ready-to-use checklists, and store all contracts and receipts in one place.",
        "social_proof": "Join the pioneers of digital construction.",
        "errors": {
            "invalid_credentials": "Invalid login credentials.",
            "user_exists": "An account with this email already exists. Try logging in instead.",
            "email_not_confirmed": "Email address not confirmed. Please check your inbox."
        }
    },
    "landing": {
        "nav": {
            "dashboard_link": "Go to Dashboard",
            "login_link": "Log In",
            "get_started": "Start for Free"
        },
        "hero": {
            "badge": "Built for private investors",
            "title": "Build your home",
            "accent": "without stress or chaos",
            "description": "Have full control over your budget, manage contractors, track progress with over 280 checkpoints, and keep all contracts in one secure place.",
            "cta_primary": "Create free account",
            "cta_secondary": "Explore features",
            "dashboard_back": "Back to Dashboard"
        },
        "features": {
            "title": "Everything you need",
            "subtitle": "Planer Budowy replaces dozens of Excel sheets, lost receipts, and scribbles with one cohesive system.",
            "budget_title": "Full budget control",
            "budget_desc": "Track every penny. Assign expenses to specific stages, monitor deviations from the baseline budget, and view clear charts (Recharts) to know exactly if you'll have enough funds until the end.",
            "checklists_title": "Over 280+ Checklist points",
            "checklists_desc": "Ready-to-use, professional inspection templates for 7 construction stages. From foundations and reinforcements to facades. Don't get cheated on site.",
            "timeline_title": "Drag & Drop Schedule",
            "timeline_desc": "Plan upcoming crews without stress. Drag stage tiles in any order on an interactive list to arrange the chronology of work as you wish.",
            "files_title": "Investor's Folder & Contract Templates",
            "files_desc": "No more searching for receipts in pocket linings. Upload invoice photos, scans of approved designs directly to a safe integrated with your project. Additionally, we offer ready-to-use contract templates (e.g., General Contractor agreement)."
        },
        "cta": {
            "title": "Build your home on a solid foundation...",
            "subtitle": "of planning.",
            "description": "Start using the platform for free. No credit cards, no hidden fees.",
            "button": "Create account and add your first project"
        },
        "footer": {
            "rights": "All rights reserved."
        }
    },
    "checklists": {
        "header_title": "Project Schedule",
        "header_desc": "Manage construction stages and checklists",
        "title": "Your Checklists",
        "page_title": "Checklists",
        "page_subtitle": "Quality control tools for every construction stage",
        "create": "Create Checklist",
        "create_new": "New checklist",
        "create_custom": "Create custom list",
        "group_by_project": "Group by Project",
        "all_projects": "All Projects",
        "no_items": "No tasks in this list.",
        "no_items_details": "No tasks. Click + to add the first one.",
        "add_item": "Add task",
        "add_item_placeholder": "New task...",
        "delete_confirm": "Are you sure you want to delete this checklist?",
        "delete_item_confirm": "Delete?",
        "template_info": "This list was created from a template.",
        "items_count": "{count} tasks",
        "checklist_name": "Checklist name",
        "save": "Create checklist",
        "templates_banner_title": "10 professional checklist templates",
        "templates_banner_desc": "Ready-to-use checklists: foundations (54 pts), slab (30 pts), shell (92 pts), windows (13 pts), installations (78 pts), insulation (13 pts), facade (18 pts).",
        "no_checklists_title": "No checklists",
        "no_checklists_desc": "You don't have any checklists for the selected projects yet. Add a new list from a template or create your own.",
        "unknown_project": "Unknown project",
        "add_from_template": "Add from template",
        "add_from_template_short": "From template",
        "select_template": "Choose a checklist template",
        "assign_to_stage": "Assign to stage",
        "no_stage": "No stage",
        "adding_template": "Adding...",
        "added_from_template": "Checklist \"{{name}}\" added successfully.",
        "select_project": "Project",
        "custom_name_placeholder": "e.g. Important tasks...",
        "list_items": "List items (tasks)",
        "add_custom": "+ Checklist"
    },
    "documents": {
        "header_title": "Documents & Templates",
        "header_desc": "Browse all project documents and use ready-made templates",
        "title": "Documents & Contracts",
        "page_title": "Documents and Templates",
        "page_subtitle": "Store scans of contracts, invoices and manage electronic signatures in one place.",
        "tab_templates": "Templates",
        "tab_my_documents": "My wallet",
        "filter_all_projects": "All sites",
        "add_document": "Add document +",
        "add_document_desc": "Upload a scan of a paper contract or send a document for signature.",
        "no_documents": "No documents uploaded",
        "no_documents_msg": "Your wallet is empty. Add your first document to start tracking it.",
        "mode_scan": "Scan / File",
        "mode_esign": "E-Signature",
        "doc_name": "Document name",
        "doc_name_placeholder": "e.g. Electrician Contract",
        "select_project": "Assign to project (optional)",
        "no_project": "None (General Document)",
        "click_to_upload": "Click or drag file here",
        "file_types_desc": "PDF or Image (JPG, PNG)",
        "esign_setup": "Signature Setup",
        "signer_name": "Recipient name",
        "signer_name_placeholder": "e.g. John Doe",
        "signer_email": "Recipient email",
        "esign_provider_info": "Document will be sent securely via {provider}.",
        "error_missing_signer": "Please provide recipient details.",
        "upload_scan": "Upload scan",
        "send_to_sign": "Send for signature",
        "uploading": "Uploading...",
        "status_signed": "Signed",
        "status_pending": "Pending",
        "status_rejected": "Rejected",
        "type_scan": "Scan",
        "type_esign": "E-Signature",
        "open_provider": "Open in BoldSign",
        "template_content_label": "Template content",
        "copy_content": "Copy content",
        "copied": "Copied",
        "delete_confirm_msg": "Are you sure you want to delete the document \"{name}\"? The file will be permanently removed from the server.",
        "status_syncing": "Syncing...",
        "tooltip_preview": "Document preview",
        "preview_error": "Could not load preview.",
        "preview_error_hint": "The file might be unavailable or corrupted.",
        "preview_not_supported": "Preview is not supported for this format.",
        "esign_preview_title": "E-Signature Preview",
        "esign_preview_desc": "BoldSign document previews require provider authorization. Click below to open the document.",
        "open_in_boldsign": "Open in BoldSign",
        "syncing_status": "Syncing status...",
        "status_synced": "Status updated!",
        "sending_request": "Sending document for signature...",
        "error_missing_fields": "Please fill all required fields"
    },
    "settings": {
        "header_title": "Account Settings",
        "header_desc": "Manage your profile and security settings",
        "account_settings": "Account Settings",
        "account_subtitle": "Manage your profile details, avatar, and security.",
        "profile_tab": "My Profile",
        "security_tab": "Security",
        "full_name": "Full Name",
        "email": "E-mail",
        "phone_number": "Phone Number",
        "email_readonly_info": "Email can only be changed in the main auth settings.",
        "save_changes": "Save Changes",
        "saving": "Saving...",
        "saved": "Saved!",
        "password_hint": "Note: Password must contain at least 8 characters, including a number and a special character.",
        "current_password": "Current Password",
        "new_password": "New Password",
        "confirm_new_password": "Confirm New Password",
        "password_success": "Password has been successfully updated!",
        "update_password": "Update password",
        "profile": {
            "photo_title": "Your photo",
            "photo_desc": "Recommended 400x400px. JPG, PNG or WebP.",
            "change_photo": "Change photo",
            "errors": {
                "select_image": "Please select an image file to upload.",
                "upload_failed": "Error uploading photo."
            }
        }
    },
    "dashboard": {
        "welcome": "Welcome back",
        "summary": "Summary",
        "total_budget": "Total Budget",
        "total_spent": "Total Spent",
        "active_projects": "Active Projects",
        "completed_stages": "Completed Stages",
        "spending_by_category": "Spending by Category",
        "materials": "Materials",
        "labor": "Labor",
        "other": "Other",
        "stats": {
            "projects": "Projects",
            "total_budget": "Total budget",
            "spent": "Spent",
            "remaining": "Remaining",
            "selected_projects": "selected projects",
            "active_projects": "active projects",
            "in_selected": "in selected projects",
            "in_all": "in all projects",
            "budget_usage": "{progress}% of budget",
            "to_use": "to use",
            "all": "All",
            "currency": "$"
        },
        "alerts": {
            "near_limit": "Warning: already used {progress}% of budget",
            "over_budget": "Budget exceeded by {amount} zł!",
            "over_budget_plural": "Budget of selected projects exceeded by {amount} zł!"
        },
        "filter": "Filter:",
        "no_projects_match": "No projects matching the criteria.",
        "recent_projects": "Your projects",
        "investment_shortcut": "Investment shortcut",
        "budget_label": "budget"
    },
    "projects": {
        "header_title": "Projects",
        "header_desc": "Manage your construction investments",
        "title": "Your Projects",
        "new_project": "New Project",
        "summary_subtitle": "Project summary and settings",
        "budget_status": "Budget Status",
        "safe": "{percent}% safe",
        "over_budget_msg": "Over Budget!",
        "near_limit_msg": "Near Limit",
        "on_track_msg": "On Track",
        "budget_exceeded": "Budget exceeded!",
        "budget_warning": "You've used 80% of your budget.",
        "stage_progress": "Stage Progress",
        "completed_stages": "Completed stages",
        "largest_category": "Largest Category",
        "highest_spending": "Highest spending category",
        "delete_shared_confirm": "Are you sure you want to remove this project from your account? This will not delete the project for the owner.",
        "delete_owner_confirm": "Are you sure you want to PERMANENTLY delete this project? This operation cannot be undone.",
        "project_name": "Project Name",
        "budget": "Budget",
        "create": "Create Project",
        "no_projects": "You don't have any projects yet.",
        "delete_confirm": "Are you sure you want to delete this project?",
        "timeline": "Timeline",
        "stages": "Construction Stages",
        "team": "Team & Sharing",
        "files": "Files & Documents",
        "add_stage": "Add stage",
        "status_todo": "To do",
        "status_in_progress": "In progress",
        "status_done": "Done",
        "stage_added": "Stage \"{{name}}\" added.",
        "stage_deleted": "Stage deleted.",
        "stage_status_changed": "Status changed to \"{{status}}\".",
        "edit_budget": "Edit budget",
        "budget_updated": "Budget updated to {{amount}} PLN.",
        "summary_title": "Project summary",
        "controls_title": "Management",
        "extra": {
            "subtitle": "Manage your own and shared building projects.",
            "empty_title": "No projects",
            "empty_desc": "Create your first project or ask for an invitation.",
            "shared_badge": "Shared",
            "budget_label": "Budget",
            "created_label": "Created"
        }
    },
    "team": {
        "title": "Team & Sharing",
        "description": "Manage access to this project. Team members can edit stages and expenses (Editor) or only view them (Viewer).",
        "manage_team": "Manage team",
        "add_person": "Add person",
        "invite": "Invite",
        "invite_title": "Invite someone to the project",
        "invite_placeholder": "email@example.com",
        "main_owner": "Main Owner",
        "you": "You (Project Creator)",
        "send_invite": "Send invite",
        "connected": "Connected",
        "waiting": "Waiting",
        "remove_member_confirm": "Are you sure you want to remove this person from the project?",
        "error_duplicate": "This user is already in the team.",
        "no_members": "No invited members."
    },
    "expenses": {
        "title": "Expenses",
        "add_expense": "Add Expense",
        "amount": "Amount",
        "category": "Category",
        "date": "Date",
        "description": "Description",
        "no_expenses": "No expenses in this project.",
        "category_materials": "Materials",
        "category_labor": "Labor",
        "category_other": "Other",
        "category_custom": "Other (custom)",
        "stage": "Stage",
        "actions": "Actions",
        "summary": "Expense summary",
        "edit_expense": "Edit expense",
        "expense_added": "Expense \"{{desc}}\" ({{amount}} PLN) added.",
        "expense_deleted": "Expense deleted.",
        "expenses_deleted": "{{count}} expenses deleted.",
        "expense_updated": "Expense updated.",
        "custom_category_label": "Own category name",
        "document_label": "Related document",
        "upload_new": "Upload new",
        "link_existing": "Link existing",
        "select_file": "Select file...",
        "file_uploaded_success": "File uploaded successfully.",
        "document": "Document",
        "by_category": "Expenses by category",
        "stages_chart_title": "Costs per Stage",
        "stages_chart_desc": "Summary of booked expenses by construction stage.",
        "no_stage": "No stage",
        "global": {
            "title": "Your Expenses",
            "subtitle": "Full history of all costs across all your investments.",
            "search_placeholder": "Search in expenses...",
            "all_projects": "All projects",
            "found_count": "Found: {count} items",
            "total_sum": "Total: ",
            "no_results": "No expenses found matching the criteria.",
            "no_description": "No description",
            "table": {
                "date": "Date",
                "project": "Project",
                "description": "Description",
                "category": "Category",
                "amount": "Amount"
            }
        }
    },
    "files": {
        "title": "Files & Documents",
        "subtitle": "Receipts, contracts, photos from construction",
        "upload": "Upload file",
        "uploading": "Uploading...",
        "no_files": "No files in this project.",
        "no_files_details": "No files. Upload your first document.",
        "delete_confirm": "Are you sure you want to delete this file?",
        "drag_drop": "Drag and drop files here",
        "drag_drop_subtitle": "or click to select from disk (PDF, JPG, PNG)",
        "select_files": "Select files",
        "download": "Download",
        "delete": "Delete",
        "size_limit": "Max file size: 10MB",
        "error_upload": "Error during file upload: {name}",
        "error_download": "Failed to generate download link.",
        "assign_stage": "Assign to stage",
        "type_pdf": "PDF",
        "type_image": "Image",
        "type_document": "Document"
    },
    "stages": {
        "title": "Construction Stages",
        "add_stage": "Add New Stage",
        "no_stages": "No stages. Add your first stage to get started.",
        "status": "Status",
        "order": "Order",
        "delete_stage_confirm": "Are you sure you want to delete this stage along with all its expenses?",
        "suggested_title": "Enter your own name or choose below...",
        "suggested_list": [
            "Land & Formalities",
            "Ground Level (Foundations, Slab)",
            "Shell Stage (Open)",
            "Shell Stage (Closed - Windows, Roof)",
            "Internal Installations",
            "Plastering & Screeds",
            "Attic Insulation",
            "Insulation & Facade",
            "Finishing Works",
            "Furnishing & Furniture",
            "Acceptance & Moving In"
        ],
        "start_date": "Start Date",
        "end_date": "End Date",
        "save_dates": "Save Dates",
        "timeline_title": "Project Schedule",
        "timeline_duration": "Duration: {days} days (from {start} to {end})",
        "no_timeline_data": "No data for schedule",
        "no_timeline_details": "Add start and end dates to construction stages.",
        "predefined": {
            "Działka": "Land & Formalities",
            "Formalności": "Paperwork",
            "Fundamenty": "Foundations",
            "Stan surowy": "Shell Stage",
            "Instalacje": "Installations",
            "Wykończenie": "Finishing Works"
        }
    },
    "activity": {
        "title": "Project History",
        "subtitle": "Recent events in the project",
        "no_logs": "No recorded history",
        "create_expense": "Added expense: {name} ({amount} zł)",
        "delete_expense": "Deleted expense: {name}",
        "delete_expense_bulk": "Deleted {count} expenses in bulk",
        "create_stage": "Created stage: {name}",
        "delete_stage": "Deleted stage: {name}",
        "update_stage_status": "Changed stage {name} status to {status}",
        "upload_file": "Uploaded file: {name}",
        "delete_file": "Deleted file: {name}",
        "delete_file_bulk": "Deleted {count} files in bulk",
        "invite_member": "Invited user: {email}",
        "remove_member": "Removed user: {email}",
        "update_stage_dates": "Changed stage dates: {name}",
        "update_expense": "Updated expense: {name}",
        "update_file_stage": "Changed file assignment: {name}",
        "update_member_role": "Changed role: {email} ({role})",
        "update_project_budget": "Changed budget to {budget} zł"
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useTranslation",
    ()=>useTranslation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$locales$2f$pl$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/lib/i18n/locales/pl.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/lib/i18n/locales/en.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
const translations = {
    pl: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$locales$2f$pl$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pl"],
    en: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$locales$2f$en$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["en"]
};
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function LanguageProvider({ children }) {
    _s();
    const [locale, setLocaleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('pl');
    const [isMounted, setIsMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            const savedLocale = localStorage.getItem('app-locale');
            if (savedLocale && (savedLocale === 'pl' || savedLocale === 'en')) {
                setLocaleState(savedLocale);
            }
            setIsMounted(true);
        }
    }["LanguageProvider.useEffect"], []);
    const setLocale = (newLocale)=>{
        setLocaleState(newLocale);
        localStorage.setItem('app-locale', newLocale);
        document.documentElement.lang = newLocale;
    };
    const t = (keyPath, variables)=>{
        const keys = keyPath.split('.');
        let current = translations[locale];
        for (const key of keys){
            if (current[key] === undefined) {
                // Fallback to Polish if English key is missing
                let fallback = translations['pl'];
                for (const k of keys){
                    if (fallback[k] === undefined) return keyPath;
                    fallback = fallback[k];
                }
                current = fallback;
                break;
            }
            current = current[key];
        }
        if (typeof current !== 'string' && !Array.isArray(current)) return keyPath;
        if (Array.isArray(current)) return current;
        if (variables) {
            let result = current;
            Object.entries(variables).forEach(([key, value])=>{
                result = result.replace(`{${key}}`, String(value));
            });
            return result;
        }
        return current;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            locale,
            setLocale,
            t
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/Desktop/planer-budowy/src/lib/i18n/LanguageContext.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "GdEAnDrdqnXr8hkeK7QgXfSycmI=");
_c = LanguageProvider;
function useTranslation() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
    if (context === undefined) {
        throw new Error('useTranslation must be used within a LanguageProvider');
    }
    return context;
}
_s1(useTranslation, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Desktop_planer-budowy_src_lib_i18n_01vjlw_._.js.map