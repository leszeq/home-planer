(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/0f1p_11tdt4a._.js","static/chunks/Desktop_planer-budowy_src_0j2ip9a._.js"],
    source: "dynamic"
});
