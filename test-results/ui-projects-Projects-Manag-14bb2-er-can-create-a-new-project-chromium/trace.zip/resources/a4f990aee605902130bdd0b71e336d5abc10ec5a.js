(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/Desktop_planer-budowy_src_0.s7ck4._.js","static/chunks/0f1p_0xi57gn._.js"],
    source: "dynamic"
});
