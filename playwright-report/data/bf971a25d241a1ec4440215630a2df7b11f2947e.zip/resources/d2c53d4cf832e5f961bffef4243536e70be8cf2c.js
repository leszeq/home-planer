(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/Desktop_planer-budowy_src_components_07e0zco._.js","static/chunks/Desktop_planer-budowy_src_0loswdy._.js","static/chunks/0f1p_@supabase_auth-js_dist_module_05eehfe._.js","static/chunks/0f1p_@dnd-kit_core_dist_core_esm_0f342o5.js","static/chunks/0f1p_date-fns_0f1nn1a._.js","static/chunks/0f1p_recharts_es6_util_02iv.~s._.js","static/chunks/0f1p_recharts_es6_state_0ufggsx._.js","static/chunks/0f1p_recharts_es6_component_1063d-d._.js","static/chunks/0f1p_recharts_es6_cartesian_0kvjt-7._.js","static/chunks/0f1p_recharts_es6_07gjbf7._.js","static/chunks/0f1p_@supabase_0lii0my._.js","static/chunks/0f1p_@radix-ui_0f-04.5._.js","static/chunks/0f1p_@floating-ui_0ke9zne._.js","static/chunks/0f1p_@reduxjs_toolkit_0any94k._.js","static/chunks/0f1p_0a7jw7s._.js"],
    source: "dynamic"
});
