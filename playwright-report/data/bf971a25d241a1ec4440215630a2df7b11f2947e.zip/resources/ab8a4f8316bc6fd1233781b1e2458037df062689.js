(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/planer-budowy/src/lib/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/@supabase/ssr/dist/module/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://atyoodbklymmxebrafpn.supabase.co"), ("TURBOPACK compile-time value", "sb_publishable_6TkfPpVxbQs6fZKglcnP0w_bCxa1Yrz"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/lib/checklist-templates.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CHECKLIST_TEMPLATES",
    ()=>CHECKLIST_TEMPLATES
]);
const CHECKLIST_TEMPLATES = {
    pl: [
        {
            id: 'poszukiwanie-dzialki',
            name: 'Poszukiwanie i zakup działki',
            description: 'Kluczowe kroki podczas wyboru i zakupu bezpiecznej działki budowlanej',
            items: [
                'Analiza Miejscowego Planu Zagospodarowania Przestrzennego (MPZP) lub WZ',
                'Weryfikacja księgi wieczystej (brak obciążeń, hipotek, służebności)',
                'Weryfikacja dostępu do drogi publicznej (bezpośredni lub służebność drogowa)',
                'Badania geotechniczne gruntu (nośność, poziom wód gruntowych)',
                'Weryfikacja istniejącego uzbrojenia terenu (woda, prąd, gaz, kanalizacja w drodze)',
                'Weryfikacja ukształtowania terenu (spadki, ryzyko zalewania, ukształtowanie)',
                'Ocena otoczenia i uciążliwości (hałas, bliskość stref przemysłowych, odległość od lasu/rzeki)',
                'Sprawdzenie ewidencji gruntów (klasa ziemi rolniczek, np. bonitacja RIII, RIV)',
                'Weryfikacja przebiegu napowietrznych i podziemnych linii energetycznych (strefy ochronne)',
                'Pomiary i wytyczenie granic działki przez uprawnionego geodetę',
                'Negocjacje cenowe i podpisanie umowy przedwstępnej',
                'Podpisanie aktu notarialnego zakupu',
                'Opłacenie podatku PPC u notariusza'
            ]
        },
        {
            id: 'administracja-formalnosci',
            name: 'Administracja i formalności',
            description: 'Etap papierologii od zakupu działki do pozwolenia na budowę',
            items: [
                'Złożenie wniosku o Warunki Zabudowy (WZ) – w przypadku braku MPZP',
                'Wystąpienie o promesę/warunki przyłączenia prądu (PGE/Tauron/itp.)',
                'Wystąpienie o promesę/warunki przyłączenia wody i kanalizacji',
                'Wystąpienie o promesę/warunki przyłączenia gazu (opcjonalnie)',
                'Wybór i zakup projektu gotowego lub zlecenie projektu indywidualnego',
                'Adaptacja projektu gotowego do warunków działki przez architekta adaptującego',
                'Projekt zagospodarowania działki (PZT)',
                'Badanie geologiczne gruntu – dołączenie opinii do projektu budowlanego (jeśli wymagane)',
                'Wyłączenie gruntu z produkcji rolnej/leśnej w starostwie (odrolnienie)',
                'Uzgodnienie wjazdu/zjazdu z drogi z zarządcą drogi (np. ZDW)',
                'Złożenie wniosku o Pozwolenie na Budowę lub zgłoszenie budowy (ze wszystkimi załącznikami)',
                'Odczekanie na uprawomocnienie się decyzji o pozwoleniu na budowę (zazwyczaj 14 dni)',
                'Pobranie i ostemplowanie Dziennika Budowy z urzędu',
                'Zgłoszenie rozpoczęcia robót budowlanych do PINB, minimum 7 dni przed startem prac',
                'Zatrudnienie Kierownika Budowy i złożenie przez niego oświadczenia o podjęciu obowiązków'
            ]
        },
        {
            id: 'przygotowanie-budowy',
            name: 'Przygotowanie działki pod budowę',
            description: 'Fizyczne prace przygotowawcze przed wkopaniem pierwszej łopaty',
            items: [
                'Wyznaczenie stref niebezpiecznych i organizacji ruchu na budowie',
                'Montaż ogrodzenia tymczasowego placu budowy',
                'Zawieszenie żółtej tablicy informacyjnej na widocznym miejscu',
                'Ustawienie zaplecza sanitarnego (Toi-Toi) dla ekipy budowlanej',
                'Zapewnienie dostępu do wody (hydrant, wykopana studnia lub zbiornik z wodą - beczkowóz/mauzer)',
                'Wykonanie tymczasowego przyłącza prądu (RB-tka budowlana obok granicy działki)',
                'Ustawienie blaszaka (kontenera) zabezpieczonego przed włamaniami na drobne narzędzia i cement',
                'Przygotowanie drogi dojazdowej dla ciężkiego sprzętu (nawiezienie i zagęszczenie kruszywa, gruzu lub płyt drogowych)',
                'Karczowanie krzewów i wycinka drzew (jeśli wymagane i uzyskano zgodę)',
                'Odsunięcie i zabezpieczenie wierzchniej warstwy ziemi roślinnej (humusu) na hałdę deponową',
                'Wytyczenie geodezyjne bryły budynku na ławach drutowych przez uprawnionego geodetę (wpis do dziennika)',
                'Zorganizowanie miejsca magazynowania stali zbrojeniowej i materiałów masowych na podkładkach',
                'Przyjaz ekipy odpowiedzialnej za fundamentowanie'
            ]
        },
        {
            id: 'fundamenty-tradycyjne',
            name: 'Fundamenty tradycyjne',
            description: 'Kompletna kontrola jakości fundamentów w technologii tradycyjnej (wylew betonowy lub bloczki)',
            items: [
                'Sprawdź wytyczenie geodezyjne działki i budynku',
                'Zweryfikuj rzędne terenu zgodnie z projektem',
                'Sprawdź wymiary wykopu (szerokość, głębokość)',
                'Zweryfikuj poziom posadowienia (niwelator/łata)',
                'Sprawdź wyrównanie dna wykopu',
                'Zweryfikuj grunt pod fundamentem (nośność, brak nawodnień)',
                'Sprawdź czy usunięto warstwę humusu',
                'Zweryfikuj podsypkę żwirową lub piaskową (grubość)',
                'Sprawdź zbrojenie ław fundamentowych (średnice, rozstaw, grubość otuliny)',
                'Zweryfikuj ciągłość strzemion w ławach',
                'Sprawdź dyblowanie zbrojenia na narożnikach',
                'Zweryfikuj wypusty zbrojeniowe pod ściany',
                'Sprawdź jakość betonu (klasa wg projektu)',
                'Zweryfikuj konsystencję betonu przy dostawie',
                'Sprawdź wylewanie betonu (brak segregacji kruszywa)',
                'Zweryfikuj wibrowanie betonu',
                'Sprawdź czy zachowane wyrównanie powierzchni ław',
                'Zweryfikuj pielęgnację betonu (nawilżanie)',
                'Sprawdź poziom wylanych ław (odchyłka max 2cm)',
                'Zweryfikuj wzajemne powiązanie ław in narożnikach',
                'Sprawdź izolację przeciwwilgociową ław (papa termozgrzewalna lub masa bitumiczna)',
                'Zweryfikuj ciągłość izolacji poziomej',
                'Sprawdź izolację pionową ścian fundamentowych',
                'Zweryfikuj jakość bloczków betonowych (wymiary, klasa)',
                'Sprawdź grubość zaprawy między bloczkami',
                'Zweryfikuj powiązanie bloczków na narożnikach (mijankowe)',
                'Sprawdź pionie i poziome ścian z bloczków',
                'Zweryfikuj szczelność spoin',
                'Sprawdź czy bloczki nie są rozbite lub uszkodzone',
                'Zweryfikuj otworowania w murze (przepusty instalacyjne)',
                'Sprawdź poziom wieńca żelbetowego',
                'Zweryfikuj zbrojenie wieńca (nośność, grubość otuliny)',
                'Sprawdź połączenie wieńca z ławą fundamentową',
                'Zweryfikuj wylew betonu wieńca',
                'Sprawdź izolację termiczną fundamentu (XPS, Styrodur)',
                'Zweryfikuj grubość warstwy izolacji termicznej',
                'Sprawdź drenaż opaskowy lub francuski',
                'Zweryfikuj szczelność drenażu',
                'Sprawdź poziom terenu przy fundamencie (odskok wodny)',
                'Zweryfikuj odprowadzenie wody ze wzgórza skarpy',
                'Sprawdź podkład betonowy pod posadzkę (grubość)',
                'Zweryfikuj wyrównanie podkładu',
                'Sprawdź folię paroizolacyjną pod posadzką',
                'Zweryfikuj ciągłość folii (zakłady, uszczelnienia)',
                'Sprawdź izolację termiczną podposadzkową (styropian, XPS)',
                'Zweryfikuj grubość izolacji termicznej podposadzkowej',
                'Sprawdź wypusty instalacyjne (wod-kan, ogrzewanie)',
                'Zweryfikuj obsypkę wykopu (kruszywo, etapowe zagęszczanie)',
                'Sprawdź zagęszczenie gruntu zagęszczarką',
                'Zweryfikuj poziom terenu po obsypce',
                'Sprawdź brak pęknięć i ubytków w fundamentach przed zasypaniem',
                'Zweryfikuj dokumentację powykonawczą fundamentów',
                'Sprawdź protokół odbioru robót fundamentowych',
                'Zweryfikuj wpis do dziennika budowy przez kierownika'
            ]
        },
        {
            id: 'plyta-fundamentowa',
            name: 'Płyta fundamentowa',
            description: 'Kontrola jakości wykonania płyty fundamentowej (technologia monolityczna)',
            items: [
                'Sprawdź wytyczenie geodezyjne płyty',
                'Zweryfikuj wymiary i kształt płyty zgodnie z projektem',
                'Sprawdź głębokość posadowienia',
                'Zweryfikuj usunięcie warstwy humusu',
                'Sprawdź grunt pod płytą (nośność, brak organiki)',
                'Zweryfikuj podsypkę (kruszywo stabilizowane, grubość min. 15cm)',
                'Sprawdź zagęszczenie podsypki',
                'Zweryfikuj izolację termiczną pod płytą (XPS, min. 15cm)',
                'Sprawdź ułożenie folii paroizolacyjnej (zakłady 20cm, taśmowanie)',
                'Zweryfikuj szalunek obwodowy płyty (prostoliniowość)',
                'Sprawdź zbrojenie dolne płyty (siatka, rozstaw, otulina min 3cm)',
                'Zweryfikuj zbrojenie górne płyty',
                'Sprawdź podkładki dystansowe pod zbrojeniem (beton, nie plastik)',
                'Zweryfikuj wypusty zbrojeniowe pod ściany',
                'Sprawdź przepusty instalacyjne (wod-kan, CO, prąd)',
                'Zweryfikuj zagrzewanie betonu (w warunkach zimowych)',
                'Sprawdź konsystencję betonu przy dostawie (slump test)',
                'Zweryfikuj klasę betonu (co najmniej C20/25 wg projektu)',
                'Sprawdź etapy wylewania i wibrowanie betonu',
                'Zweryfikuj wyrównanie i zatarcie powierzchni',
                'Sprawdź pielęgnację betonu (folią lub mata)',
                'Zweryfikuj poziom ukończonej płyty (odchyłka max 5mm/2m)',
                'Sprawdź brak rys i pęknięć po stwardnieniu',
                'Zweryfikuj brak pustek i kawern w betonie',
                'Sprawdź izolację termiczną obwodową (cokół XPS)',
                'Zweryfikuj ciągłość izolacji obwodowej',
                'Sprawdź uszczelnienie przejść instalacyjnych',
                'Zweryfikuj protokół odbioru płyty fundamentowej',
                'Sprawdź dokumentację fotograficzną zbrojenia przed betonowaniem',
                'Zweryfikuj wpis do dziennika budowy'
            ]
        },
        {
            id: 'stan-surowy-otwarty',
            name: 'Stan surowy otwarty',
            description: 'Kompleksowa kontrola jakości budynku w stanie surowym otwartym (ściany, stropy, dach)',
            items: [
                'Sprawdź oś budynku i wymiary rzutu (geodeta)',
                'Zweryfikuj pionowość ścian zewnętrznych (odchyłka max 1cm/m)',
                'Sprawdź poziom pierwszej warstwy ścian',
                'Zweryfikuj grubość spoin między bloczkami/cegłą',
                'Sprawdź powiązanie bloczków na narożnikach',
                'Zweryfikuj prawidłowość otworu na okna (wymiary, ościeżnice)',
                'Sprawdź prawidłowość otworów drzwiowych',
                'Zweryfikuj nadproża nad otworami (rodzaj, nośność)',
                'Sprawdź zbrojenie nadproży betonowych',
                'Zweryfikuj wypełnienie nadproży prefabrykowanych',
                'Sprawdź wieniec żelbetowy na poziomie stropu (zbrojenie)',
                'Zweryfikuj beton wieńca (klasa, ciągłość)',
                'Sprawdź połączenie wieńca ze ścianami',
                'Zweryfikuj zbrojenie słupów i trzpieni',
                'Sprawdź grubość ścian nośnych (zgodność z projektem)',
                'Zweryfikuj grubość ścian działowych',
                'Sprawdź materiał ścian działowych (cegła silikatowa, bloczki)',
                'Zweryfikuj powiązanie ścian działowych z nośnymi',
                'Sprawdź wypełnienie ścian szczelinowych',
                'Zweryfikuj izolację akustyczną między ścianami',
                'Sprawdź strop żelbetowy monolityczny (zbrojenie dołem i górą)',
                'Zweryfikuj szalunek stropu (szczelność, poziom)',
                'Sprawdź podparcie szalunku (rozstaw podpór)',
                'Zweryfikuj beton stropu (klasa, wibrowanie)',
                'Sprawdź grubość płyty stropowej (wg projektu)',
                'Zweryfikuj strop prefabrykowany (Teriva/Filigran – montaż kierunkowy)',
                'Sprawdź nadbeton na stropie prefabrykowanym',
                'Zweryfikuj otwory w stropie (schody, instalacje)',
                'Sprawdź poziom gotowego stropu (odchyłka max 1cm)',
                'Zweryfikuj brak rys i pęknięć w stropie',
                'Sprawdź belki stropowe drewniane (klasa C24, przekrój wg projektu)',
                'Zweryfikuj rozstaw belek drewnianych',
                'Sprawdź zakotwienie belek w wieńcu',
                'Zweryfikuj impregnację drewna (ognioochronna, grzybochronna)',
                'Sprawdź murłatę (gatunek drewna, połączenia)',
                'Zweryfikuj zakotwienie murłaty do wieńca (kotwy M16)',
                'Sprawdź krokwie (przekrój, rozstaw, nacięcia)',
                'Zweryfikuj kalenicę i płatwie',
                'Sprawdź słupy i miecze więźby dachowej',
                'Zweryfikuj metalowe łączniki więźby (mauerlat, kątowniki)',
                'Sprawdź pionowość słupów więźby',
                'Zweryfikuj symetrię dachu (pomiary przekątnych)',
                'Sprawdź kąt nachylenia połaci (zgodność z projektem)',
                'Zweryfikuj łaty i kontrłaty (wymiary, rozstaw)',
                'Sprawdź folię wstępnego krycia (FWK), klasy W1 lub W3',
                'Zweryfikuj montaż FWK (zakłady, taśmowanie)',
                'Sprawdź pokrycie dachowe (dachówka, blachodachówka)',
                'Zweryfikuj uszczelnienie kalenicowania',
                'Sprawdź mocowanie obróbek blacharskich (rynny, pasy nadrynnowe)',
                'Zweryfikuj odprowadzenie wody z dachu (rury spustowe)',
                'Sprawdź okna dachowe / świetliki (montaż, szczelność)',
                'Zweryfikuj kominy (wymiary, pionowość, głowice)',
                'Sprawdź uszczelnienie przejścia komina przez dach',
                'Zweryfikuj wyłaz dachowy (dostęp, okucia)',
                'Sprawdź schody wewnętrzne lub zewnętrzne',
                'Zweryfikuj poziom podłogi na każdym piętrze',
                'Sprawdź brak pęknięć w ścianach po ciężkich deszczach',
                'Zweryfikuj odwodnienie terenu przy budynku',
                'Sprawdź brak zastoiny wody przy fundamentach',
                'Zweryfikuj zabezpieczenie budynku przed dewastacją (okna, drzwi tymczasowe)',
                'Sprawdź prawidłowość inwentaryzacji geodezyjnej powykonawczej',
                'Zweryfikuj zgodność z projektem budowlanym i warunkami zabudowy',
                'Sprawdź dziennik budowy – wpisy kierownika i inspektora',
                'Zweryfikuj protokół odbioru robót murowych',
                'Sprawdź protokół odbioru stropu',
                'Zweryfikuj protokół odbioru więźby dachowej',
                'Sprawdź protokół odbioru pokrycia dachowego',
                'Zweryfikuj dokumentację fotograficzną poszczególnych etapów',
                'Sprawdź czy budynek jest zawarty w obszarze planu lub WZ',
                'Zweryfikuj zgodność z pozwoleniem na budowę',
                'Sprawdź czy nie przekroczono linii zabudowy',
                'Zweryfikuj odległości od granic działki',
                'Sprawdź projekt pomocniczy (np. obliczenia więźby)',
                'Zweryfikuj czy kierownik budowy jest na bieżąco z dziennikiem',
                'Sprawdź czy materiały posiadają deklaracje właściwości użytkowych',
                'Zweryfikuj certyfikaty wyrobów budowlanych',
                'Sprawdź brak uszkodzeń mechanicznych elementów konstrukcyjnych',
                'Zweryfikuj czystość i porządek na placu budowy',
                'Sprawdź organizację placu budowy (ogrodzenie, tablica)',
                'Zweryfikuj warunki bhp na budowie',
                'Sprawdź zabezpieczenie otworów (ekrany, balustrady tymczasowe)',
                'Zweryfikuj oznakowanie stref niebezpiecznych',
                'Sprawdź stan techniczny rusztowań',
                'Zweryfikuj certyfikaty rusztowań',
                'Sprawdź piorunochron na budowie (jeśl wymagany)',
                'Zweryfikuj licznik energii elektrycznej na budowie',
                'Sprawdź ujęcie wody na budowie',
                'Zweryfikuj węzeł sanitarny dla pracowników',
                'Sprawdź składowisko materiałów budowlanych',
                'Zweryfikuj kontener na odpady budowlane'
            ]
        },
        {
            id: 'okna-drzwi',
            name: 'Okna i drzwi',
            description: 'Kontrola montażu i jakości stolarki okiennej i drzwiowej',
            items: [
                'Sprawdź wymiary okien zgodne z projektem',
                'Zweryfikuj współczynnik U okien (wg dokumentacji, max 0.9 W/m²K)',
                'Sprawdź profil ramy (grubość, komory, klasa)',
                'Zweryfikuj rodzaj szyby (trojszybowa zalecana)',
                'Sprawdź pionowość i poziomość ościeżnicy',
                'Zweryfikuj montaż na łącznikach systemowych (nie na piankę)',
                'Sprawdź montaż paroprzepuszczalnej taśmy od zewnątrz',
                'Zweryfikuj montaż paroizolacyjnej taśmy od wewnątrz',
                'Sprawdź wypełnienie szczelin pianką niskoprzężną',
                'Zweryfikuj poziom parapetu zewnętrznego (odpad wody)',
                'Sprawdź parapet wewnętrzny (mocowanie, uszczelnienie)',
                'Zweryfikuj działanie skrzydeł (otwieranie, zamykanie, uchylanie)',
                'Sprawdź drzwi wejściowe (klasa, RC2 zalecana)'
            ]
        },
        {
            id: 'instalacje-tynki-wylewki',
            name: 'Instalacje, tynki, wylewki',
            description: 'Kontrola wykonania wszystkich instalacji wewnętrznych, tynków i wylewek',
            items: [
                'Sprawdź projekt instalacji elektrycznej (uprawnienia projektanta)',
                'Zweryfikuj przekroje przewodów (NYM 3×2,5 dla gniazdek)',
                'Sprawdź obwody rozdzielnicze (ilość, zabezpieczenia)',
                'Zweryfikuj rozdzielnicę elektryczną (typ, ochrona, RCD)',
                'Sprawdź montaż puszek elektrycznych (głębokość, poziom)',
                'Zweryfikuj trasy kablowe (brak krzyżowania naprężonych kabli)',
                'Sprawdź uziemienie i ochronę przepięciową',
                'Zweryfikuj protokół z pomiaru instalacji elektrycznej',
                'Sprawdź projekt instalacji wod-kan (uprawnienia)',
                'Zweryfikuj materiał rur (PP, PEX, miedź)',
                'Sprawdź próbę ciśnieniową instalacji wodnej (6 bar przez 1h)',
                'Zweryfikuj spadki kanalizacji (min 2% dla DN 110)',
                'Sprawdź odpowietrzenie pionu kanalizacyjnego',
                'Zweryfikuj rewizje i czyszczaki na kanalizacji',
                'Sprawdź projekt instalacji grzewczej CO',
                'Zweryfikuj materiał rur grzewczych (PEX, wielowarstwowa)',
                'Sprawdź próbę ciśnieniową CO (6 bar przez 1h)',
                'Zweryfikuj rozdzielacze ogrzewania podłogowego (strefowanie)',
                'Sprawdź głębokość frezów pod rury (min 2 cm otuliny)',
                'Zweryfikuj projekt wentylacji mechanicznej (HRV/ERV)',
                'Sprawdź centrale wentylacyjną (rekuperacja min 80%)',
                'Zweryfikuj trasy kanałów wentylacyjnych (ocynk, flex)',
                'Sprawdź szczelność kanałów wentylacyjnych',
                'Zweryfikuj anemostaty i kratki wentylacyjne',
                'Sprawdź instalację gazową (próba szczelności)',
                'Zweryfikuj protokół odbioru gazu (gazownia)',
                'Sprawdź tynk wewnętrzny (gipsowy lub cementowo-wapienny)',
                'Zweryfikuj przygotowanie podłoża przed tynkowaniem',
                'Sprawdź grubość tynku (min 1 cm gipsowego)',
                'Zweryfikuj prostoliniowość tynku (łata 2m, odchyłka max 3mm)',
                'Sprawdź brak rys skurczowych i pęknięć tynku',
                'Zweryfikuj kąty i narożniki (profile aluminiowe)',
                'Sprawdź tynk zewnętrzny / elewacyjny (siatka zbrojąca)',
                'Zweryfikuj głębokość zatopienia siatki w tynku (min 2mm)',
                'Sprawdź podkład tynkarski na elewacji',
                'Zweryfikuj wylewkę cementową lub anhydrytową',
                'Sprawdź grubość wylewki (min 4,5 cm na COG, 6,5 cm na styro)',
                'Zweryfikuj poziom wylewki (łata 2m, odchyłka max 3mm)',
                'Sprawdź zbrojenie wylewki (siatka lub fiber)',
                'Zweryfikuj dylatacje wylewki (przy ścianach, co max 30m²)',
                'Sprawdź pielęgnację wylewki cementowej',
                'Zweryfikuj wilgotność wylewki przed układaniem podłogi',
                'Sprawdź wylewkę podgrzewana COG (próba grzejna)',
                'Zweryfikuj projekt elektryczny tablicy rozdzielczej',
                'Sprawdź UPS i zabezpieczenia przepięciowe',
                'Zweryfikuj instalację alarmową i domofon',
                'Sprawdź instalację sieciową i TV (Cat6, RG-6)',
                'Zweryfikuj instalację oświetlenia tarasów i zewnętrzna',
                'Sprawdź czy wszystkie inst. posiadają protokoły odbioru',
                'Zweryfikuj wpis kierownika do dziennika budowy',
                'Sprawdź zakrycia instalacji przed wylaniem wylewki (dokumentacja foto)',
                'Zweryfikuj zgodność z projektem (brak samowoli)',
                'Sprawdź czy materiały posiadają atesty i certyfikaty',
                'Zweryfikuj końcowy protokół odbioru wszystkich instalacji',
                'Sprawdź próbę ogrzewania (nagrzewanie całego systemu)',
                'Zweryfikuj zbilansowanie hydrauliczne ogrzewania',
                'Sprawdź sprawność pompy ciepła lub kotła',
                'Zweryfikuj regulację zaworu trójdrogowego',
                'Sprawdź bufory ciepła i zasobniki CWU',
                'Zweryfikuj instalację fotowoltaiczną (jeśli jest)',
                'Sprawdź falownik PV (certyfikat, parametry)',
                'Zweryfikuj izolację termiczną przewodów grzewczych',
                'Sprawdź izolację akustyczną pod wylewką',
                'Zweryfikuj projekt elektryczny podpisany przez kierownika',
                'Sprawdź certyfikaty materiałów izolacyjnych',
                'Zweryfikuj zgodność z normami PN-EN',
                'Sprawdź przejścia pożarowe przez ściany i stropy',
                'Zweryfikuj uszczelnienia ognioochronne (typ EI60+)',
                'Sprawdź wymiarowanie przekrojów kanałów wentylacji',
                'Zweryfikuj próbę rurociągów sprężonym powietrzem',
                'Sprawdź zasuwy i zawory na instalacji (typ, wymagania)',
                'Zweryfikuj prawidłowość oznaczeń elementów instalacji'
            ]
        },
        {
            id: 'termoizolacja-poddasza',
            name: 'Termoizolacja poddasza',
            description: 'Kontrola wykonania izolacji termicznej i paroizolacji poddasza',
            items: [
                'Sprawdź projekt izolacji (grubość wełny, wg WT2021)',
                'Zweryfikuj materiał izolacyjny (wełna mineralna λ ≤ 0,035)',
                'Sprawdź pierwszy layer wełny między krokwiami (szczelne wypełnienie)',
                'Zweryfikuj drugi layer wełny pod krokwiami (prostopadle)',
                'Sprawdź grubość łączną izolacji (min 30 cm dla WT2021)',
                'Zweryfikuj szczelność złączeń warstw wełny (bez mostków)',
                'Sprawdź folie paroizolacyjna (klasa Sd ≥ 5m)',
                'Zweryfikuj zakłady folii paroizolacyjnej (min 15cm, taśmowane)',
                'Sprawdź połączenie folii ze ścianami (taśma butylowa)',
                'Zweryfikuj brak uszkodzeń i dziur w folii',
                'Sprawdź szczelinę wentylacyjną za FWK (min 2cm)',
                'Zweryfikuj drożność kanałów wentylacyjnych pod dachem',
                'Sprawdź izolację okien dachowych (mansardowanie)'
            ]
        },
        {
            id: 'elewacja',
            name: 'Elewacja',
            description: 'Kontrola wykonania ocieplenia i tynku elewacyjnego metodą ETICS',
            items: [
                'Sprawdź projekt ocieplenia (grubość styropianu, typ)',
                'Zweryfikuj gatunek styropianu (EPS100 λ≤0,033 lub EPS150 cokół)',
                'Sprawdź przygotowanie podłoża (myjka, grunt)',
                'Zweryfikuj listwy startowe (poziom, mocowanie)',
                'Sprawdź klej do styropianu (aplikacja metodą obwodowo-punktową)',
                'Zweryfikuj przyklejenie płyt (min 40% powierzchni)',
                'Sprawdź układ płyt styropianu (mijankowy, odskok na narożnikach)',
                'Zweryfikuj kołkowanie styropianu (długość, ilość min 6 szt/m²)',
                'Sprawdź siatka zbrojąca (gramatura min 145 g/m²)',
                'Zweryfikuj głębokość zatopienia siatki w masie klejowej',
                'Sprawdź zakłady siatki na narożnikach (ukośne wstawki)',
                'Zweryfikuj czas sezonowania podkładu (min 72h)',
                'Sprawdź podkład tynkarski (kolor zbliżony do tynku)',
                'Zweryfikuj tynk elewacyjny (typ: silikonowy, mineralny)',
                'Sprawdź grubość tynku (zgodność z uziarnieniem)',
                'Zweryfikuj jednolitość faktury tynku (bez smug, odcieni)',
                'Sprawdź obróbki blacharskie (parapety, nakrywy)',
                'Zweryfikuj uszczelnienie połączeń elewacji z stolarką'
            ]
        }
    ],
    en: [
        {
            id: 'poszukiwanie-dzialki',
            name: 'Land Search and Purchase',
            description: 'Key steps during the selection and purchase of a safe construction plot',
            items: [
                'Analysis of Local Spatial Development Plan (MPZP) or Zoning Approval (WZ)',
                'Verification of the land and mortgage register (no encumbrances, mortgages, easements)',
                'Verification of public road access (direct or road easement)',
                'Geotechnical soil testing (load-bearing capacity, groundwater level)',
                'Verification of existing utilities (water, electricity, gas, sewage in the road)',
                'Verification of land topography (slopes, flood risk, shape)',
                'Assessment of surroundings and nuisances (noise, proximity to industrial zones, distance from forest/river)',
                'Check of land records (agricultural land class, e.g., RIII, RIV)',
                'Verification of overhead and underground power lines (protective zones)',
                'Measurements and boundary staking by an authorized surveyor',
                'Price negotiations and signing a preliminary agreement',
                'Signing the notarized purchase deed',
                'Payment of Transfer Tax (PCC) at the notary'
            ]
        },
        {
            id: 'administracja-formalnosci',
            name: 'Administration and Formalities',
            description: 'Paperwork stage from plot purchase to building permit',
            items: [
                'Submission of application for Zoning Approval (WZ) – if no MPZP',
                'Application for electricity connection conditions (PGE/Tauron/etc.)',
                'Application for water and sewage connection conditions',
                'Application for gas connection conditions (optional)',
                'Selection and purchase of a ready-made project or commissioning an individual project',
                'Adaptation of the ready-made project to plot conditions by an adapting architect',
                'Plot development project (PZT)',
                'Geological soil testing – including the opinion in the building project (if required)',
                'Exclusion of land from agricultural/forest production in the starosty',
                'Agreement for entry/exit from the road with the road manager (e.g., ZDW)',
                'Submission of application for Building Permit or building notification (with all attachments)',
                'Wait for the building permit decision to become final (usually 14 days)',
                'Download and stamp the Building Logbook from the office',
                'Notification of commencement of construction works to PINB, at least 7 days before starting',
                'Hiring a Site Manager and submitting their statement on undertaking duties'
            ]
        },
        {
            id: 'przygotowanie-budowy',
            name: 'Site Preparation',
            description: 'Physical preparation work before digging the first spade',
            items: [
                'Designation of danger zones and traffic organization on the construction site',
                'Installation of temporary fencing for the construction site',
                'Hanging the yellow information board in a visible place',
                'Setting up sanitary facilities (portable toilet) for the construction crew',
                'Ensuring access to water (hydrant, dug well, or water tank)',
                'Execution of temporary electricity connection (RB-tka construction box)',
                'Setting up a secure shed/container for small tools and cement',
                'Preparation of access road for heavy equipment (hauling and compacting aggregate or road plates)',
                'Grubbing of shrubs and tree clearing (if required and consent obtained)',
                'Removal and storage of the top layer of plant soil (humus) on a deposit heap',
                'Surveying layout of the building body on wire batter boards by an authorized surveyor',
                'Organization of a storage area for reinforcing steel and mass materials on pads',
                'Arrival of the crew responsible for foundation works'
            ]
        },
        {
            id: 'fundamenty-tradycyjne',
            name: 'Traditional Foundations',
            description: 'Complete quality control of foundations in traditional technology (concrete pour or blocks)',
            items: [
                'Check surveying layout of plot and building',
                'Verify terrain levels according to the project',
                'Check excavation dimensions (width, depth)',
                'Verify foundation level (leveler/staff)',
                'Check leveling of excavation floor',
                'Verify soil under foundation (load capacity, no water)',
                'Check if humus layer has been removed',
                'Verify gravel or sand bedding (thickness)',
                'Check reinforcement of foundation footings (diameters, spacing, cover thickness)',
                'Verify continuity of stirrups in footings',
                'Check reinforcement doweling at corners',
                'Verify reinforcement starters for walls',
                'Check concrete quality (class according to project)',
                'Verify concrete consistency during delivery',
                'Check concrete pouring (no aggregate segregation)',
                'Verify concrete vibration',
                'Check if foundation footing surface leveling is maintained',
                'Verify concrete curing (moisturization)',
                'Check level of poured footings (max deviation 2cm)',
                'Verify mutual connection of footings at corners',
                'Check damp-proof insulation of footings (torch-on felt or bituminous mass)',
                'Verify continuity of horizontal insulation',
                'Check vertical insulation of foundation walls',
                'Verify quality of concrete blocks (dimensions, class)',
                'Check thickness of mortar between blocks',
                'Verify block bonding at corners (offset)',
                'Check plumbness and level of block walls',
                'Verify tightness of joints',
                'Check if blocks are not broken or damaged',
                'Verify openings in the wall (installation sleeves)',
                'Check level of the reinforced concrete beam',
                'Verify beam reinforcement (load capacity, cover thickness)',
                'Check connection of the beam with the foundation footing',
                'Verify beam concrete pour',
                'Check thermal insulation of foundation (XPS, Styrodur)',
                'Verify thickness of thermal insulation layer',
                'Check perimeter or French drainage',
                'Verify drain tightness',
                'Check ground level at foundation (drip edge)',
                'Verify water drainage from embankment slope',
                'Check concrete floor base (thickness)',
                'Verify leveling of the base',
                'Check vapor barrier film under the floor',
                'Verify continuity of the film (overlaps, sealings)',
                'Check floor thermal insulation (styrofoam, XPS)',
                'Verify thickness of floor thermal insulation',
                'Check installation outlets (water-sewage, heating)',
                'Verify excavation backfill (aggregate, staged compaction)',
                'Check soil compaction with a compactor',
                'Verify ground level after backfilling',
                'Check for lack of cracks and defects in foundations before burial',
                'Verify as-built documentation for foundations',
                'Check foundation works acceptance report',
                'Verify entry in the building logbook by the manager'
            ]
        },
        {
            id: 'plyta-fundamentowa',
            name: 'Foundation Slab',
            description: 'Quality control of foundation slab execution (monolithic technology)',
            items: [
                'Check surveying layout of the slab',
                'Verify dimensions and shape of the slab according to project',
                'Check foundation depth',
                'Verify removal of humus layer',
                'Check soil under the slab (load capacity, no organic matter)',
                'Verify bedding (stabilized aggregate, min. 15cm thickness)',
                'Check bedding compaction',
                'Verify thermal insulation under the slab (XPS, min. 15cm)',
                'Check layout of vapor barrier film (20cm overlaps, taping)',
                'Verify perimeter formwork of the slab (straightness)',
                'Check lower reinforcement of the slab (mesh, spacing, min 3cm cover)',
                'Verify upper reinforcement of the slab',
                'Check spacer pads under reinforcement (concrete, not plastic)',
                'Verify reinforcement starters for walls',
                'Check installation sleeves (water-sewage, central heating, electricity)',
                'Verify concrete heating (in winter conditions)',
                'Check concrete consistency during delivery (slump test)',
                'Verify concrete class (at least C20/25 according to project)',
                'Check pouring stages and concrete vibration',
                'Verify surface leveling and floating',
                'Check concrete curing (with film or mat)',
                'Verify level of the finished slab (max 5mm/2m deviation)',
                'Check for lack of cracks and fissures after hardening',
                'Verify lack of voids and cavities in concrete',
                'Check perimeter thermal insulation (XPS plinth)',
                'Verify continuity of perimeter insulation',
                'Check sealing of installation penetrations',
                'Verify foundation slab acceptance report',
                'Check photographic documentation of reinforcement before concreting',
                'Verify entry in the building logbook'
            ]
        },
        {
            id: 'stan-surowy-otwarty',
            name: 'Open Shell State',
            description: 'Comprehensive quality control of the building in the open shell state (walls, slabs, roof)',
            items: [
                'Check building axis and floor plan dimensions (surveyor)',
                'Verify verticality of exterior walls (max deviation 1cm/m)',
                'Check level of the first wall layer',
                'Verify joint thickness between blocks/bricks',
                'Check block bonding at corners',
                'Verify correctness of window openings (dimensions, frames)',
                'Check correctness of door openings',
                'Verify lintels over openings (type, load capacity)',
                'Check reinforcement of concrete lintels',
                'Verify filling of prefabricated lintels',
                'Check reinforced concrete beam at slab level (reinforcement)',
                'Verify beam concrete (class, continuity)',
                'Check connection of the beam with walls',
                'Verify reinforcement of columns and pillars',
                'Check thickness of load-bearing walls (project compliance)',
                'Verify thickness of partition walls',
                'Check material of partition walls (silicate bricks, blocks)',
                'Verify connection of partition walls with load-bearing walls',
                'Check cavity wall filling',
                'Verify acoustic insulation between walls',
                'Check monolithic reinforced concrete slab (lower and upper reinforcement)',
                'Verify slab formwork (tightness, level)',
                'Check formwork support (support spacing)',
                'Verify slab concrete (class, vibration)',
                'Check slab thickness (according to project)',
                'Verify prefabricated slab (Teriva/Filigran – directional assembly)',
                'Check topping on prefabricated slab',
                'Verify openings in the slab (stairs, installations)',
                'Check level of finished slab (max deviation 1cm)',
                'Verify lack of cracks and fissures in the slab',
                'Check wooden floor beams (C24 class, section according to project)',
                'Verify wooden beam spacing',
                'Check beam anchoring in the wall plate/beam',
                'Verify wood impregnation (fire-retardant, anti-fungal)',
                'Check wall plate (wood species, connections)',
                'Verify anchoring of the wall plate to the beam (M16 anchors)',
                'Check rafters (section, spacing, notches)',
                'Verify ridge and purlins',
                'Check columns and braces of the roof structure',
                'Verify metal connectors of the structure (mauerlat, angle brackets)',
                'Check verticality of structure columns',
                'Verify roof symmetry (diagonal measurements)',
                'Check inclination angle of roof planes (project compliance)',
                'Verify battens and counter-battens (dimensions, spacing)',
                'Check initial roofing film (FWK), class W1 or W3',
                'Verify FWK installation (overlaps, taping)',
                'Check roofing material (tiles, metal tiles)',
                'Verify ridge sealing',
                'Check fixing of metal flashings (gutters, eaves strips)',
                'Verify water drainage from the roof (downpipes)',
                'Check roof windows / skylights (installation, tightness)',
                'Verify chimneys (dimensions, verticality, heads)',
                'Check sealing of chimney roof penetration',
                'Verify roof hatch (access, hardware)',
                'Check internal or external stairs',
                'Verify floor level on each floor',
                'Check lack of cracks in walls after heavy rains',
                'Verify terrain drainage near the building',
                'Check lack of water ponding near foundations',
                'Verify protection of the building against vandalism (temporary windows/doors)',
                'Check correctness of as-built surveying inventory',
                'Verify compliance with building project and zoning conditions',
                'Check building logbook – entries by manager and inspector',
                'Verify masonry works acceptance report',
                'Check slab acceptance report',
                'Verify roof structure acceptance report',
                'Check roofing acceptance report',
                'Verify photographic documentation of individual stages',
                'Check if building is within the plan area or WZ',
                'Verify compliance with building permit',
                'Check if building lines are not exceeded',
                'Verify distances from plot boundaries',
                'Check auxiliary project (e.g., roof structure calculations)',
                'Verify if site manager is up to date with the logbook',
                'Check if materials have declarations of performance',
                'Verify certificates of building products',
                'Check lack of mechanical damage to structural elements',
                'Verify cleanliness and order on the construction site',
                'Check construction site organization (fencing, board)',
                'Verify occupational safety and health conditions on site',
                'Check protection of openings (screens, temporary railings)',
                'Verify marking of dangerous zones',
                'Check technical condition of scaffoldings',
                'Verify scaffolding certificates',
                'Check lightning rod on site (if required)',
                'Verify electric energy meter on site',
                'Check water intake on site',
                'Verify sanitary facilities for workers',
                'Check building materials storage site',
                'Verify construction waste container'
            ]
        },
        {
            id: 'okna-drzwi',
            name: 'Windows and Doors',
            description: 'Quality control of window and door joinery installation and quality',
            items: [
                'Check window dimensions according to project',
                'Verify window U-value (acc. to documentation, max 0.9 W/m²K)',
                'Check frame profile (thickness, chambers, class)',
                'Verify glazing type (triple-glazed recommended)',
                'Check verticality and horizontality of the frame',
                'Verify installation on system connectors (not just foam)',
                'Check vapor-permeable tape installation on the outside',
                'Verify vapor-barrier tape installation on the inside',
                'Check joint filling with low-expansion foam',
                'Verify external window sill level (water runoff)',
                'Check internal window sill (fixing, sealing)',
                'Verify operation of sashes (opening, closing, tilting)',
                'Check entrance doors (class, RC2 recommended)'
            ]
        },
        {
            id: 'instalacje-tynki-wylewki',
            name: 'Installations, Plasters, Screeds',
            description: 'Quality control of all internal installations, plasters, and screeds',
            items: [
                'Check electrical installation project (designer qualifications)',
                'Verify wire sections (NYM 3×2.5 for sockets)',
                'Check distributional circuits (quantity, protections)',
                'Verify electrical distribution board (type, protection, RCD)',
                'Check installation of electrical boxes (depth, level)',
                'Verify cable routes (no crossing of stretched cables)',
                'Check grounding and surge protection',
                'Verify electrical installation measurement report',
                'Check water-sewage installation project (qualifications)',
                'Verify pipe material (PP, PEX, copper)',
                'Check water system pressure test (6 bar for 1h)',
                'Verify sewage slopes (min 2% for DN 110)',
                'Check sewage stack venting',
                'Verify inspections and cleanouts on sewage system',
                'Check central heating (CO) installation project',
                'Verify heating pipe material (PEX, multilayer)',
                'Check CO system pressure test (6 bar for 1h)',
                'Verify underfloor heating manifolds (zoning)',
                'Check depth of grooves for pipes (min 2 cm cover)',
                'Verify mechanical ventilation project (HRV/ERV)',
                'Check ventilation unit (recovery min 80%)',
                'Verify ventilation duct routes (galvanized, flex)',
                'Check ventilation duct tightness',
                'Verify anemostats and ventilation grilles',
                'Check gas installation (leak test)',
                'Verify gas acceptance report (gas company)',
                'Check internal plaster (gypsum or cement-lime)',
                'Verify substrate preparation before plastering',
                'Check plaster thickness (min 1 cm for gypsum)',
                'Verify plaster straightness (2m staff, max 3mm deviation)',
                'Check for lack of shrinkage cracks and plaster fissures',
                'Verify angles and corners (aluminum profiles)',
                'Check external / facade plaster (reinforcing mesh)',
                'Verify embedding depth of mesh in plaster (min 2mm)',
                'Check plaster base on the facade',
                'Verify cement or anhydrite screed',
                'Check screed thickness (min 4.5 cm for underfloor heating, 6.5 cm on styro)',
                'Verify screed level (2m staff, max 3mm deviation)',
                'Check screed reinforcement (mesh or fiber)',
                'Verify screed expansion joints (at walls, max 30m²)',
                'Check cement screed curing',
                'Verify screed humidity before floor laying',
                'Check heated floor screed (heating test)',
                'Verify electrical project of distribution board',
                'Check UPS and surge protection',
                'Verify alarm installation and intercom',
                'Check network and TV installation (Cat6, RG-6)',
                'Verify terrace and external lighting installation',
                'Check if all installations have acceptance reports',
                'Verify site manager\'s entry in the logbook',
                'Check installation coverage before screed pour (photo documentation)',
                'Verify compliance with the project',
                'Check if materials have approvals and certificates',
                'Verify final acceptance report of all installations',
                'Check heating test (warming up the whole system)',
                'Verify hydraulic balancing of the heating system',
                'Check efficiency of heat pump or boiler',
                'Verify 3-way valve adjustment',
                'Check thermal buffers and DHW tanks',
                'Verify photovoltaic installation (if present)',
                'Check PV inverter (certificate, parameters)',
                'Verify thermal insulation of heating pipes',
                'Check acoustic insulation under the screed',
                'Verify electrical project signed by the manager',
                'Check certificates of insulation materials',
                'Verify compliance with PN-EN standards',
                'Check fire penetrations through walls and slabs',
                'Verify fire-stop seals (EI60+ type)',
                'Check dimensioning of ventilation duct sections',
                'Verify pipe system test with compressed air',
                'Check gates and valves on the installation (type, requirements)',
                'Verify correctness of installation element markings'
            ]
        },
        {
            id: 'termoizolacja-poddasza',
            name: 'Attic Thermal Insulation',
            description: 'Quality control of attic thermal insulation and vapor barrier execution',
            items: [
                'Check insulation project (wool thickness, acc. to WT2021)',
                'Verify insulation material (mineral wool λ ≤ 0.035)',
                'Check first layer of wool between rafters (tight filling)',
                'Verify second layer of wool under rafters (perpendicular)',
                'Check total insulation thickness (min 30 cm for WT2021)',
                'Verify tightness of wool layer joins (no bridges)',
                'Check vapor barrier film (class Sd ≥ 5m)',
                'Verify overlaps of vapor barrier film (min 15cm, taped)',
                'Check connection of the film with walls (butyl tape)',
                'Verify lack of damage and holes in the film',
                'Check ventilation gap behind FWK (min 2cm)',
                'Verify clearance of ventilation channels under the roof',
                'Check roof window insulation (mansard work)'
            ]
        },
        {
            id: 'elewacja',
            name: 'Facade',
            description: 'Quality control of facade insulation and plaster execution using ETICS method',
            items: [
                'Check insulation project (styrofoam thickness, type)',
                'Verify styrofoam grade (EPS100 λ≤0.033 or EPS150 plinth)',
                'Check substrate preparation (washer, primer)',
                'Verify starter strips (level, fixing)',
                'Check styrofoam adhesive (perimeter-point application)',
                'Verify board adhesion (min 40% area)',
                'Check styrofoam board layout (offset, corner overlap)',
                'Verify styrofoam doweling (length, quantity min 6 pcs/m²)',
                'Check reinforcing mesh (weight min 145 g/m²)',
                'Verify embedding depth of mesh in adhesive mass',
                'Check mesh overlaps at corners (diagonal inserts)',
                'Verify curing time of the base (min 72h)',
                'Check plaster primer (color close to plaster)',
                'Verify facade plaster (type: silicone, mineral)',
                'Check plaster thickness (acc. to grain size)',
                'Verify uniformity of plaster texture (no streaks, shades)',
                'Check metal flashings (window sills, covers)',
                'Verify sealing of facade connections with joinery'
            ]
        }
    ]
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:d8f512 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStage",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70a2dd4e741183b6e4c9b3adc42186da3ac1afc879":{"name":"createStage"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70a2dd4e741183b6e4c9b3adc42186da3ac1afc879", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createStage");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:a1ceb2 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateStageStatus",
    ()=>$$RSC_SERVER_ACTION_3
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70c05b53ed57d0cfd91c801c88b8505f7a07ffc395":{"name":"updateStageStatus"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70c05b53ed57d0cfd91c801c88b8505f7a07ffc395", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateStageStatus");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:bd5e7e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteStage",
    ()=>$$RSC_SERVER_ACTION_5
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"6063eb83d5c494ef026d21397f4955771de6b38d74":{"name":"deleteStage"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("6063eb83d5c494ef026d21397f4955771de6b38d74", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteStage");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:4a5aec [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateStagesOrder",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60de7f263c7f82568b3eae83a6368ec79899dd195a":{"name":"updateStagesOrder"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60de7f263c7f82568b3eae83a6368ec79899dd195a", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateStagesOrder");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:3c1546 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateStageDates",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7875ed23299a143326ff2074b21ac21198b0bd9516":{"name":"updateStageDates"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7875ed23299a143326ff2074b21ac21198b0bd9516", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateStageDates");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:c919d6 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateStageName",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70b9128f8b202309ef34241ea3f56af5502fdf92ed":{"name":"updateStageName"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70b9128f8b202309ef34241ea3f56af5502fdf92ed", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateStageName");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:119147 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toggleChecklistItem",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70d7ec09102f29f14c46b5c27e50aa8beb5cb5c7d3":{"name":"toggleChecklistItem"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70d7ec09102f29f14c46b5c27e50aa8beb5cb5c7d3", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "toggleChecklistItem");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:bb802d [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteChecklist",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4033f70790f0fe0d8b657210fbaef3c78c7ade0bf2":{"name":"deleteChecklist"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4033f70790f0fe0d8b657210fbaef3c78c7ade0bf2", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteChecklist");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:b840f7 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addChecklistItem",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"703fe6e4def170de635a7c216279e9bfa60f5f63ea":{"name":"addChecklistItem"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("703fe6e4def170de635a7c216279e9bfa60f5f63ea", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addChecklistItem");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:92e670 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteChecklistItem",
    ()=>$$RSC_SERVER_ACTION_7
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4012b375a7f376e3e26aaa0d7f770d6306d8c9ead0":{"name":"deleteChecklistItem"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4012b375a7f376e3e26aaa0d7f770d6306d8c9ead0", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteChecklistItem");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:503c2e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateChecklistItemsOrder",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60692dbb8959a221614cff5ec12cbe34f431f2090a":{"name":"updateChecklistItemsOrder"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60692dbb8959a221614cff5ec12cbe34f431f2090a", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateChecklistItemsOrder");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:1c814e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCustomChecklist",
    ()=>$$RSC_SERVER_ACTION_3
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"788f572920a1bd2cb84c671fef5d22973e43202d28":{"name":"createCustomChecklist"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("788f572920a1bd2cb84c671fef5d22973e43202d28", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createCustomChecklist");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/data:78e10c [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createChecklistFromTemplate",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"781e8af794120aa83e40976d47546e90924cc3bf80":{"name":"createChecklistFromTemplate"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/checklists/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("781e8af794120aa83e40976d47546e90924cc3bf80", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createChecklistFromTemplate");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:2368d7 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "inviteMember",
    ()=>$$RSC_SERVER_ACTION_12
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"701c0921205f0fd7b261d5abd2adb3a5d4eb8b170e":{"name":"inviteMember"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("701c0921205f0fd7b261d5abd2adb3a5d4eb8b170e", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "inviteMember");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:71c9ce [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "removeMember",
    ()=>$$RSC_SERVER_ACTION_13
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60fad7f8264f3620bc197a9a3066f458be04e8e7d4":{"name":"removeMember"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60fad7f8264f3620bc197a9a3066f458be04e8e7d4", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "removeMember");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:0d8aa3 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateMemberRole",
    ()=>$$RSC_SERVER_ACTION_14
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"708f5c2ba4da68f239275b38fcd74c5d1ffe769cfb":{"name":"updateMemberRole"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("708f5c2ba4da68f239275b38fcd74c5d1ffe769cfb", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateMemberRole");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/documents/data:d8ede0 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getBoldSignUrl",
    ()=>$$RSC_SERVER_ACTION_5
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40c0e5bfa7c794e0c81a54875d574dc8af99f50d45":{"name":"getBoldSignUrl"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/documents/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40c0e5bfa7c794e0c81a54875d574dc8af99f50d45", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getBoldSignUrl");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:676bfd [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createExpense",
    ()=>$$RSC_SERVER_ACTION_7
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60760e7672e505b333f4c91bb5c6dc093cc119ddfc":{"name":"createExpense"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60760e7672e505b333f4c91bb5c6dc093cc119ddfc", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createExpense");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:c324c6 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteExpense",
    ()=>$$RSC_SERVER_ACTION_8
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60127ff9a67e7e9cecf7d5abbf8c552781f2558416":{"name":"deleteExpense"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60127ff9a67e7e9cecf7d5abbf8c552781f2558416", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteExpense");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:ae2ac2 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteMultipleExpenses",
    ()=>$$RSC_SERVER_ACTION_9
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60d2d69b18a821f28091eb8dc20cb51a4f44090c28":{"name":"deleteMultipleExpenses"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60d2d69b18a821f28091eb8dc20cb51a4f44090c28", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteMultipleExpenses");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:5f5cc2 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateExpense",
    ()=>$$RSC_SERVER_ACTION_10
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70b4d5c44917bd8c8ab420e134efed52fe4eb6479b":{"name":"updateExpense"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70b4d5c44917bd8c8ab420e134efed52fe4eb6479b", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateExpense");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:e38a44 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getProjectCategories",
    ()=>$$RSC_SERVER_ACTION_16
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40ac0841249b7dfdea2fefdaeace8ac4d35e28060d":{"name":"getProjectCategories"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ac0841249b7dfdea2fefdaeace8ac4d35e28060d", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getProjectCategories");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:9b2e95 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCategory",
    ()=>$$RSC_SERVER_ACTION_17
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60e8d958ecae6e097b4a72c09041e5d011c27d0efe":{"name":"createCategory"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60e8d958ecae6e097b4a72c09041e5d011c27d0efe", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createCategory");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/data:dd03ca [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addFileRecord",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7ed83afabf1f1c4361a4cd9923d94faed31b26f83f":{"name":"addFileRecord"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7ed83afabf1f1c4361a4cd9923d94faed31b26f83f", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addFileRecord");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/data:5f556a [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteFile",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"705425085b2c15c0e0a7f5489743e9216c7f222efe":{"name":"deleteFile"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("705425085b2c15c0e0a7f5489743e9216c7f222efe", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteFile");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/data:86fbe7 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteMultipleFiles",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"6023b9875b51ec515e44328d4ac0435f67ab1b6e0f":{"name":"deleteMultipleFiles"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("6023b9875b51ec515e44328d4ac0435f67ab1b6e0f", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteMultipleFiles");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/data:249d37 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateFileStage",
    ()=>$$RSC_SERVER_ACTION_3
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"70523bd9e85168ccc352e43a941b5c857cae6194fd":{"name":"updateFileStage"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/files/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("70523bd9e85168ccc352e43a941b5c857cae6194fd", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateFileStage");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:0e4cff [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteProject",
    ()=>$$RSC_SERVER_ACTION_15
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40be2c1ba0d98c84ff1514b8fdb4bf38c04c60c786":{"name":"deleteProject"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40be2c1ba0d98c84ff1514b8fdb4bf38c04c60c786", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteProject");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/data:f8a918 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateProjectBudget",
    ()=>$$RSC_SERVER_ACTION_11
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"60252730e8497fd83643c273575717a9fd756e460b":{"name":"updateProjectBudget"}},"Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60252730e8497fd83643c273575717a9fd756e460b", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateProjectBudget");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProjectDetailClient",
    ()=>ProjectDetailClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$stages$2f$stage$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/stages/stage-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$stages$2f$project$2d$timeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/stages/project-timeline.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$team$2f$team$2d$management$2d$sheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/team/team-management-sheet.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$expenses$2f$expense$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/expenses/expense-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$expenses$2f$stages$2d$cost$2d$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/expenses/stages-cost-chart.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$files$2f$file$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/files/file-list.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$ui$2f$print$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/ui/print-button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$delete$2d$project$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/projects/delete-project-button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$detail$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/projects/project-detail-client.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$skeletons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/projects/project-skeletons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$activity$2d$sheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/components/projects/activity-sheet.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function canEditRole(role) {
    return role === 'owner' || role === 'editor';
}
function ProjectDetailClient({ projectId }) {
    _s();
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { data, isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'project',
            projectId
        ],
        queryFn: {
            "ProjectDetailClient.useQuery": async ()=>{
                const { data: { user } } = await supabase.auth.getUser();
                if (!user) throw new Error("No user");
                const [projectRes, membersRes, stagesRes, expensesRes, filesRes, logsRes] = await Promise.all([
                    supabase.from('projects').select('*').match({
                        id: projectId
                    }).single(),
                    supabase.from('project_members').select('*').match({
                        id: projectId
                    }),
                    supabase.from('stages').select('*').match({
                        project_id: projectId
                    }).order('order', {
                        ascending: true
                    }),
                    supabase.from('expenses').select('*').match({
                        project_id: projectId
                    }).order('date', {
                        ascending: false
                    }),
                    supabase.from('project_files').select('*').match({
                        project_id: projectId
                    }).order('created_at', {
                        ascending: false
                    }),
                    supabase.from('activity_logs').select('*').match({
                        project_id: projectId
                    }).order('created_at', {
                        ascending: false
                    }).limit(30)
                ]);
                const project = projectRes.data;
                if (!project) return null;
                // Roles logic
                const memberships = membersRes.data || [];
                let role = 'viewer';
                if (project.user_id === user.id) {
                    role = 'owner';
                } else {
                    const m = memberships.find({
                        "ProjectDetailClient.useQuery.m": (m)=>m.user_id === user.id
                    }["ProjectDetailClient.useQuery.m"]);
                    if (m) role = m.role;
                }
                const canEditProject = canEditRole(role);
                // Owner for sheet
                const ownerEmail = memberships.find({
                    "ProjectDetailClient.useQuery": (m)=>m.user_id === project.user_id
                }["ProjectDetailClient.useQuery"])?.email || "";
                const ownerProfile = {
                    full_name: ownerEmail || 'Właściciel'
                };
                const { data: checklists } = await supabase.from('checklists').select('*, checklist_items(*)').match({
                    project_id: projectId
                });
                // Manual join for profiles using project_members to avoid relationship/permission errors
                const logs = logsRes.data || [];
                const logsWithProfiles = logs.map({
                    "ProjectDetailClient.useQuery.logsWithProfiles": (log)=>{
                        const member = memberships.find({
                            "ProjectDetailClient.useQuery.logsWithProfiles.member": (m)=>m.user_id === log.user_id
                        }["ProjectDetailClient.useQuery.logsWithProfiles.member"]);
                        return {
                            ...log,
                            profiles: {
                                full_name: member?.email || 'Użytkownik'
                            }
                        };
                    }
                }["ProjectDetailClient.useQuery.logsWithProfiles"]);
                return {
                    user,
                    project,
                    members: memberships,
                    stages: stagesRes.data || [],
                    expenses: expensesRes.data || [],
                    files: filesRes.data || [],
                    logs: logsWithProfiles,
                    role,
                    canEditProject,
                    ownerProfile,
                    ownerEmail,
                    checklists: checklists || []
                };
            }
        }["ProjectDetailClient.useQuery"],
        staleTime: 2 * 60 * 1000
    });
    // Loading state (only if no cache)
    if (isLoading && !data) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-8 animate-fade-in",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/dashboard/projects",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "icon",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                    lineNumber: 101,
                                    columnNumber: 16
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 100,
                                columnNumber: 14
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                            lineNumber: 99,
                            columnNumber: 12
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$skeletons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageHeaderSkeleton"], {}, void 0, false, {
                            fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                            lineNumber: 104,
                            columnNumber: 12
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                    lineNumber: 98,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$skeletons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StatsSkeleton"], {}, void 0, false, {
                    fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                    lineNumber: 106,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$skeletons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TimelineSkeleton"], {}, void 0, false, {
                    fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                    lineNumber: 107,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
            lineNumber: 97,
            columnNumber: 7
        }, this);
    }
    const result = data;
    if (!result) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notFound"])();
    const project = result.project;
    const canEditProject = result.canEditProject;
    // Pass entire collections to Stats Client to render rich charts
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8 pb-12 animate-fade-in",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row sm:items-center gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/dashboard/projects",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "ghost",
                                    size: "icon",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                        lineNumber: 126,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                    lineNumber: 125,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 124,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$detail$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProjectHeaderClient"], {
                                name: project.name
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 129,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "sm:ml-auto flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$activity$2d$sheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ActivitySheet"], {
                                logs: result.logs
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 133,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$team$2f$team$2d$management$2d$sheet$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TeamManagementSheet"], {
                                projectId: project.id,
                                ownerId: project.user_id,
                                ownerName: result.ownerProfile?.full_name || "",
                                ownerEmail: result.ownerEmail,
                                currentUserId: result.user?.id || '',
                                members: result.members || [],
                                userRole: result.role
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 135,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$ui$2f$print$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PrintButton"], {}, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            canEditProject && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$delete$2d$project$2d$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DeleteProjectButton"], {
                                projectId: project.id,
                                isShared: project.user_id !== result.user?.id
                            }, void 0, false, {
                                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                                lineNumber: 146,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 131,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 md:grid-cols-2 auto-rows-fr gap-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$detail$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProjectBudgetCard"], {
                        project: project,
                        expenses: result.expenses
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 153,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$detail$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProjectStagesCard"], {
                        stages: result.stages
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 154,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$projects$2f$project$2d$detail$2d$client$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProjectExpensesPieChart"], {
                        expenses: result.expenses
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 155,
                        columnNumber: 10
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$expenses$2f$stages$2d$cost$2d$chart$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StagesCostChart"], {
                        expenses: result.expenses,
                        stages: result.stages
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 156,
                        columnNumber: 10
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                lineNumber: 152,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$stages$2f$project$2d$timeline$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProjectTimeline"], {
                stages: result.stages
            }, void 0, false, {
                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                lineNumber: 163,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$stages$2f$stage$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StageList"], {
                        projectId: project.id,
                        stages: result.stages,
                        checklists: result.checklists,
                        canEdit: canEditProject
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$expenses$2f$expense$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExpenseList"], {
                        projectId: project.id,
                        expenses: result.expenses,
                        stages: result.stages.map((s)=>({
                                id: s.id,
                                name: s.name
                            })),
                        files: result.files,
                        userId: result.user?.id || '',
                        canEdit: canEditProject
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 174,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$components$2f$files$2f$file$2d$list$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FileList"], {
                        projectId: project.id,
                        userId: project.user_id,
                        files: result.files,
                        stages: result.stages.map((s)=>({
                                id: s.id,
                                name: s.name
                            })),
                        canEdit: canEditProject
                    }, void 0, false, {
                        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                        lineNumber: 183,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/planer-budowy/src/app/(dashboard)/dashboard/projects/[id]/ProjectDetailClient.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
} // trigger rebuild
_s(ProjectDetailClient, "0VB955moqGTEiUXXbAcRWgIKjHQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = ProjectDetailClient;
var _c;
__turbopack_context__.k.register(_c, "ProjectDetailClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/planer-budowy/src/hooks/use-file-upload.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFileUpload",
    ()=>useFileUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/lib/supabase/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/planer-budowy/src/lib/i18n/LanguageContext.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function useFileUpload({ userId, onSuccess, maxSizeMB = 50, storageBucket = 'project-files' }) {
    _s();
    const { t } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"])();
    const [isUploading, setIsUploading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [uploadProgress, setUploadProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const uploadFiles = async (files, saveRecord, customStoragePathPrefix)=>{
        if (!files || files.length === 0) return;
        setIsUploading(true);
        setUploadProgress(0);
        const toastId = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].loading(t('files.uploading') || 'Przesyłanie...');
        try {
            const fileArray = Array.from(files);
            // 1. Validation
            for (const file of fileArray){
                if (file.size > maxSizeMB * 1024 * 1024) {
                    throw new Error(t('files.error_too_large', {
                        name: file.name,
                        size: maxSizeMB
                    }) || `Plik ${file.name} jest za duży (max ${maxSizeMB}MB)`);
                }
            }
            const maxProgressPerFile = 100 / fileArray.length;
            // 2. Process uploads
            for(let i = 0; i < fileArray.length; i++){
                const file = fileArray[i];
                const fileExt = file.name.split('.').pop();
                const randomName = Math.random().toString(36).substring(2) + '-' + Date.now();
                // Dynamic path based on prefix or default
                const storagePath = customStoragePathPrefix ? `${customStoragePathPrefix}/${randomName}.${fileExt}` : `${userId}/${randomName}.${fileExt}`;
                // Upload to Storage
                const { error: storageError } = await supabase.storage.from(storageBucket).upload(storagePath, file, {
                    cacheControl: '3600',
                    upsert: false
                });
                if (storageError) throw storageError;
                // Save Metadata via provided callback
                const response = await saveRecord(file, storagePath);
                if (!response.success) {
                    // Cleanup storage if DB save fails
                    await supabase.storage.from(storageBucket).remove([
                        storagePath
                    ]);
                    throw new Error(response.error);
                }
                setUploadProgress(Math.round((i + 1) * maxProgressPerFile));
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(t('common.success') || 'Pomyślnie przesłano pliki', {
                id: toastId
            });
            if (onSuccess) onSuccess();
            return {
                success: true
            };
        } catch (error) {
            console.error('Upload hook error:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.message || t('common.error'), {
                id: toastId
            });
            return {
                success: false,
                error: error.message
            };
        } finally{
            setIsUploading(false);
            setUploadProgress(0);
        }
    };
    return {
        uploadFiles,
        isUploading,
        uploadProgress
    };
}
_s(useFileUpload, "UgVv5BAeguQm5z+4gnpsqtfdM8U=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$planer$2d$budowy$2f$src$2f$lib$2f$i18n$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Desktop_planer-budowy_src_0loswdy._.js.map